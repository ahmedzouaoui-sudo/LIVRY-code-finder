import React, { useRef } from 'react';
import { Search, Lightbulb, Database, ArrowRight, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Department } from '../types';
import { triggerHaptic } from '../utils/haptics';

export const HomeScreen: React.FC = () => {
  const { searchQuery, setSearchQuery, setActiveTab, setSelectedDepartment, role, products } = useApp();
  const inputRef = useRef<HTMLInputElement>(null);

  const handleQuickDept = (dept: Department) => {
    triggerHaptic('light');
    setSelectedDepartment(dept);
    setActiveTab('library');
  };

  return (
    <div className="w-full flex-1 flex flex-col justify-between max-w-[650px] mx-auto px-4 py-3 sm:py-5 min-h-[calc(100dvh-60px)] pb-safe">
      {/* Spacer to balance layout vertically */}
      <div className="flex-1" />

      {/* Main Search Bar Area */}
      <div className="w-full max-w-[650px] mx-auto flex flex-col items-center my-auto">
        {/* Brand Banner Above Search Bar */}
        <div className="w-full flex items-center justify-center mb-4 sm:mb-7 px-3">
          <img
            src="/assets/aistudio/barre_de_recherch_a0bb2929.png"
            alt="Aswak Assalam, Livry, Marjane"
            className="w-auto h-14 sm:h-20 max-w-[92%] sm:max-w-[440px] object-contain select-none pointer-events-none drop-shadow-xs"
            loading="eager"
            decoding="async"
          />
        </div>

        {/* Big Search Input Field */}
        <div
          onClick={() => inputRef.current?.focus()}
          className="w-full max-w-[650px] h-[72px] sm:h-[86px] bg-[#FFFFFF] rounded-[22px] shadow-[0_4px_16px_rgba(7,89,164,0.1)] border-2 border-[#0759A4]/25 hover:border-[#0759A4] flex items-center px-4 sm:px-5 transition-all focus-within:border-[#0759A4] focus-within:ring-4 focus-within:ring-[#0759A4]/15 cursor-text"
        >
          {/* Search Icon aligned inside the field */}
          <Search className="w-6 h-6 sm:w-7 sm:h-7 text-[#0759A4] shrink-0 mr-3" />

          {/* Search Input (Mobile Optimized: no autocorrect, search enter key) */}
          <input
            ref={inputRef}
            type="search"
            inputMode="text"
            enterKeyHint="search"
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Code (2, 3, 4 chiffres) ou nom..."
            className="w-full h-full bg-transparent border-none outline-none text-[#171717] font-extrabold text-[17px] sm:text-[22px] placeholder:text-gray-400 placeholder:font-bold"
          />
        </div>

        {/* Quick Department Shortcuts for fast 1-tap mobile picking */}
        <div className="w-full flex items-center justify-center gap-1.5 sm:gap-2 mt-3.5 flex-wrap px-1">
          <button
            type="button"
            onClick={() => handleQuickDept('Fruits et légumes')}
            className="px-2.5 py-1.5 rounded-[12px] bg-white border border-[#155B48]/25 text-[#155B48] font-bold text-[11px] shadow-2xs hover:bg-[#E8F5E9] active:scale-95 transition cursor-pointer select-none"
          >
            🍎 Fruits & Légumes
          </button>
          <button
            type="button"
            onClick={() => handleQuickDept('Boucherie et volaille')}
            className="px-2.5 py-1.5 rounded-[12px] bg-white border border-[#B93838]/25 text-[#B93838] font-bold text-[11px] shadow-2xs hover:bg-[#FFEBEE] active:scale-95 transition cursor-pointer select-none"
          >
            🥩 Boucherie
          </button>
          <button
            type="button"
            onClick={() => handleQuickDept('Fromage et charcuterie')}
            className="px-2.5 py-1.5 rounded-[12px] bg-white border border-[#0757A6]/25 text-[#0757A6] font-bold text-[11px] shadow-2xs hover:bg-[#FFF3CD] active:scale-95 transition cursor-pointer select-none"
          >
            🧀 Stand Fromage
          </button>
          <button
            type="button"
            onClick={() => handleQuickDept('Boulangerie et pâtisserie')}
            className="px-2.5 py-1.5 rounded-[12px] bg-white border border-[#F9A825]/30 text-[#92400E] font-bold text-[11px] shadow-2xs hover:bg-[#FFF8E1] active:scale-95 transition cursor-pointer select-none"
          >
            🥐 Boulangerie
          </button>
        </div>
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Bottom Navigation */}
      <div className="w-full max-w-[650px] mx-auto pt-3 pb-1 space-y-2.5">
        {/* Bouton direct vers les Données si connecté en Admin */}
        {role === 'Admin' && (
          <button
            type="button"
            onClick={() => {
              triggerHaptic('medium');
              setActiveTab('admin');
            }}
            className="w-full py-3 px-4 bg-gradient-to-r from-[#B43167] via-[#942353] to-[#7B1D45] text-white rounded-[18px] shadow-[0_4px_16px_rgba(180,49,103,0.25)] hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-between cursor-pointer select-none border border-white/20"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-[10px] bg-white/20 flex items-center justify-center shrink-0">
                <Database className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <div className="font-black text-xs sm:text-sm leading-tight">
                  Panneau Données & Base (Admin)
                </div>
                <div className="text-[10px] text-pink-100 font-medium">
                  Tableur CSV 11 colonnes, Supabase & {products.length} articles
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 bg-white text-[#B43167] font-black text-xs px-2.5 py-1 rounded-[10px] shadow-xs shrink-0">
              <span>Data</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        )}

        <button
          type="button"
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('library');
          }}
          className="w-full h-[52px] sm:h-[58px] bg-[#0759A4] text-[#FFFFFF] rounded-[18px] font-bold text-base sm:text-lg shadow-[0_4px_14px_rgba(7,89,164,0.22)] hover:bg-[#064a88] active:scale-[0.98] transition-all flex items-center justify-center cursor-pointer select-none"
        >
          Bibliothèque des Rayons
        </button>

        {/* Bouton Astuces taht bibliotheque */}
        <button
          type="button"
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('tips');
          }}
          className="w-full h-[48px] sm:h-[52px] bg-[#FFFFFF] border-2 border-[#0759A4]/25 text-[#0759A4] hover:bg-[#EBF4FC]/60 rounded-[18px] font-bold text-sm sm:text-base shadow-2xs active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer select-none"
        >
          <Lightbulb className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span>Astuces & Tutos ({role === 'Livreur' ? 'Livreur' : 'Pickeur'})</span>
        </button>
      </div>
    </div>
  );
};
