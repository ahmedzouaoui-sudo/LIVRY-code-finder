import React, { useState, useMemo, useRef, useEffect } from 'react';
import { ArrowLeft, ShoppingBag, AlertCircle, Lock, Search, X, Database } from 'lucide-react';
import { Department, Product } from '../types';
import { DEPARTMENT_CONFIGS, filterProducts, getProductBarcodeVariants, getCleanProductCode } from '../utils/productUtils';
import { useApp } from '../context/AppContext';

interface ProductListScreenProps {
  products: Product[];
  selectedDepartment: Department | null;
  initialQuery?: string;
  onBack: () => void;
  onSelectProduct: (p: Product) => void;
}

export const ProductListScreen: React.FC<ProductListScreenProps> = ({
  products,
  selectedDepartment,
  initialQuery,
  onBack,
  onSelectProduct,
}) => {
  const { showToast, searchQuery, setSearchQuery, role, setActiveTab } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  // Local search query for searching within a specific department
  const [deptSearchQuery, setDeptSearchQuery] = useState<string>('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  const deptConfig = selectedDepartment ? DEPARTMENT_CONFIGS[selectedDepartment] : null;

  // The active query depends on whether we are in global search mode or department mode
  const activeQuery = selectedDepartment ? deptSearchQuery : (searchQuery || initialQuery || '');

  // Auto-focus search input when in global search mode
  useEffect(() => {
    if (!selectedDepartment && searchInputRef.current) {
      searchInputRef.current.focus();
      const len = searchInputRef.current.value.length;
      searchInputRef.current.setSelectionRange(len, len);
    }
  }, [selectedDepartment]);

  // Extract unique categories within this department (excluding XXXX items)
  const categories = useMemo(() => {
    const list = selectedDepartment
      ? products.filter(
          (p) =>
            p.department === selectedDepartment &&
            p.isEnabled &&
            p.code?.toUpperCase() !== 'XXXX'
        )
      : products.filter(
          (p) => p.isEnabled && p.code?.toUpperCase() !== 'XXXX'
        );

    const unique = Array.from(new Set(list.map((p) => p.category).filter(Boolean)));
    return unique.sort();
  }, [products, selectedDepartment]);

  // Filter products by query (2, 3, 4 digit codes, barcodes, names), department and category
  const filtered = useMemo(() => {
    return filterProducts(
      products,
      activeQuery,
      selectedDepartment || 'ALL',
      selectedCategory,
      false,
      false
    );
  }, [products, activeQuery, selectedDepartment, selectedCategory]);

  const title = selectedDepartment || 'Recherche de produits';

  const handleCardClick = (product: Product, isCodeUnavailable: boolean) => {
    if (isCodeUnavailable) {
      showToast('Code indisponible pour cet article');
      return;
    }
    onSelectProduct(product);
  };

  const handleClearSearch = () => {
    if (selectedDepartment) {
      setDeptSearchQuery('');
    } else {
      setSearchQuery('');
      onBack();
    }
  };

  return (
    <div className="w-full max-w-[650px] mx-auto px-3.5 py-3 pb-16 flex flex-col min-h-[calc(100vh-65px)]">
      {/* Top Header with Back Button */}
      <div className="flex items-center gap-2.5 mb-2.5">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] text-[#0759A4] bg-white border border-[#E0E0E6]/80 shadow-2xs hover:bg-[#EBF4FC] active:scale-95 transition font-bold text-xs shrink-0 cursor-pointer select-none"
          aria-label="Retour"
        >
          <ArrowLeft className="w-4 h-4 text-[#0759A4]" />
          <span>Retour</span>
        </button>

        <h1 className="text-sm sm:text-base font-bold text-[#171717] truncate flex-1">
          {title}
        </h1>

        <span className="text-[11px] font-bold text-[#333333] bg-white px-2 py-0.5 rounded-[10px] border border-gray-200 shrink-0">
          {filtered.length} art.
        </span>

        {role === 'Admin' && (
          <button
            type="button"
            onClick={() => setActiveTab('admin')}
            className="flex items-center gap-1 px-2.5 py-1 rounded-[10px] bg-[#FDF0F5] hover:bg-[#FCE4EC] text-[#B43167] border border-[#B43167]/30 text-[11px] font-black transition active:scale-95 cursor-pointer shadow-2xs shrink-0 select-none"
            title="Ouvrir le panneau Données"
          >
            <Database className="w-3.5 h-3.5" />
            <span>Données Data</span>
          </button>
        )}
      </div>

      {/* Global Search Input (when selectedDepartment is null) */}
      {!selectedDepartment && (
        <div className="w-full mb-3">
          <div className="w-full h-[52px] bg-white rounded-[16px] shadow-[0_2px_10px_rgba(7,89,164,0.08)] border-2 border-[#0759A4]/35 flex items-center px-4 transition-all focus-within:border-[#0759A4] focus-within:ring-2 focus-within:ring-[#0759A4]/15">
            <Search className="w-5 h-5 text-[#0759A4] shrink-0 mr-3" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Code (2, 3, 4 chiffres) ou nom..."
              className="w-full h-full bg-transparent border-none outline-none text-[#171717] font-bold text-sm sm:text-base placeholder:text-gray-400 placeholder:font-normal"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={handleClearSearch}
                className="p-1 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition shrink-0 ml-1 cursor-pointer"
                aria-label="Effacer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          {searchQuery.trim() && (
            <div className="flex items-center justify-between px-1 mt-1.5 text-[11px] font-bold text-gray-500">
              <span>Résultats pour : &ldquo;{searchQuery.trim()}&rdquo;</span>
              <span>{filtered.length} trouvé{filtered.length > 1 ? 's' : ''}</span>
            </div>
          )}
        </div>
      )}

      {/* Department Search Input (when selectedDepartment is not null) */}
      {selectedDepartment && (
        <div className="w-full mb-2.5">
          <div className="w-full h-[44px] bg-white rounded-[14px] shadow-2xs border border-[#E0E0E6]/90 flex items-center px-3.5 transition-all focus-within:border-[#0759A4] focus-within:ring-2 focus-within:ring-[#0759A4]/15">
            <Search className="w-4 h-4 text-gray-400 shrink-0 mr-2.5" />
            <input
              type="text"
              value={deptSearchQuery}
              onChange={(e) => setDeptSearchQuery(e.target.value)}
              placeholder={`Code (2, 3, 4 chiffres) ou nom dans ce rayon...`}
              className="w-full h-full bg-transparent border-none outline-none text-[#171717] font-bold text-xs sm:text-sm placeholder:text-gray-400 placeholder:font-normal"
            />
            {deptSearchQuery && (
              <button
                type="button"
                onClick={handleClearSearch}
                className="p-1 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition shrink-0 ml-1 cursor-pointer"
                aria-label="Effacer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Categories Filter Tabs (Horizontal Scrollable Chips) */}
      {categories.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 no-scrollbar select-none">
          <button
            type="button"
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1.5 rounded-[12px] text-xs font-bold transition shrink-0 cursor-pointer ${
              selectedCategory === 'ALL'
                ? 'text-white shadow-xs'
                : 'bg-white text-gray-700 border border-gray-200/90 hover:bg-gray-50'
            }`}
            style={
              selectedCategory === 'ALL'
                ? {
                    backgroundColor: deptConfig?.accentColor || '#0759A4',
                    borderColor: deptConfig?.accentColor || '#0759A4',
                  }
                : undefined
            }
          >
            Tous ({products.filter((p) => (!selectedDepartment || p.department === selectedDepartment) && p.isEnabled && p.code?.toUpperCase() !== 'XXXX').length})
          </button>

          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-[12px] text-xs font-bold transition shrink-0 cursor-pointer ${
                  isSelected
                    ? 'text-white shadow-xs'
                    : 'bg-white text-gray-700 border border-gray-200/90 hover:bg-gray-50'
                }`}
                style={
                  isSelected
                    ? {
                        backgroundColor: deptConfig?.accentColor || '#0759A4',
                        borderColor: deptConfig?.accentColor || '#0759A4',
                      }
                    : undefined
                }
              >
                {cat}
              </button>
            );
          })}
        </div>
      )}

      {/* Product Cards Grid: 1 hda 1 (2 cols), Moraba3at bhal card, image kbira taht mnha code o smia */}
      {/* fles card dyal produit khli card bloun dyal categorie, code o smia bnefs loun d text d categorie */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5">
        {filtered.length > 0 ? (
          filtered.map((product) => {
            const productDeptConfig =
              DEPARTMENT_CONFIGS[product.department] ||
              deptConfig ||
              DEPARTMENT_CONFIGS['Fruits et légumes'];

            const variants = getProductBarcodeVariants(product);
            const hasBarcodes = variants.length > 0;
            const hasValidShortCode = Boolean(
              product.code &&
                product.code.trim() !== '' &&
                product.code.trim() !== '-' &&
                product.code.trim().toUpperCase() !== 'XXXX'
            );
            // Only unavailable if it has NEITHER a valid short code NOR any barcode!
            const isCodeUnavailable = !hasValidShortCode && !hasBarcodes;

            return (
              <div
                key={product.id}
                onClick={() => handleCardClick(product, isCodeUnavailable)}
                style={{
                  backgroundColor: isCodeUnavailable ? '#F9F9FB' : productDeptConfig.bgColor,
                  borderColor: isCodeUnavailable
                    ? '#E5E7EB'
                    : `${productDeptConfig.accentColor}30`,
                }}
                className={`flex flex-col rounded-[18px] border-2 transition-all select-none p-2.5 sm:p-3 overflow-hidden ${
                  isCodeUnavailable
                    ? 'opacity-60 cursor-not-allowed'
                    : 'shadow-[0_2px_8px_rgba(0,0,0,0.03)] hover:shadow-md hover:scale-[1.01] active:scale-[0.98] cursor-pointer'
                }`}
              >
                {/* 1. Big Image on Top (Moraba3 aspect-square) */}
                <div
                  className={`relative w-full aspect-square rounded-[14px] bg-white border border-black/5 flex items-center justify-center overflow-hidden mb-2 p-2 ${
                    isCodeUnavailable ? 'grayscale-25' : ''
                  }`}
                >
                  {product.imageUrl ? (
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      loading="lazy"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div
                      className="w-full h-full rounded-[10px] flex items-center justify-center"
                      style={{
                        backgroundColor: productDeptConfig.tagBg,
                        color: productDeptConfig.accentColor,
                      }}
                    >
                      <ShoppingBag className="w-10 h-10 opacity-70" />
                    </div>
                  )}

                  {/* Lock badge if code indisponible */}
                  {isCodeUnavailable && (
                    <div
                      className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 backdrop-blur-xs flex items-center justify-center text-white shadow-xs"
                      title="Code indisponible"
                    >
                      <Lock className="w-3 h-3" />
                    </div>
                  )}
                </div>

                {/* 2. Code Underneath (bnefs loun d text d categorie) */}
                <div className="mb-1.5 flex items-center">
                  {isCodeUnavailable ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-[6px] bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs">
                      <AlertCircle className="w-3 h-3 text-amber-600 shrink-0" />
                      <span className="truncate">Code indisponible</span>
                    </span>
                  ) : (
                    <span
                      className="inline-block text-xs sm:text-[13px] font-mono font-black px-2 py-0.5 rounded-[6px] tracking-wider shadow-2xs border"
                      style={{
                        backgroundColor: productDeptConfig.tagBg,
                        color: productDeptConfig.tagText,
                        borderColor: `${productDeptConfig.accentColor}35`,
                      }}
                    >
                      {hasValidShortCode ? getCleanProductCode(product.code) : variants[0]?.code}
                    </span>
                  )}
                </div>

                {/* 3. Name Underneath (bnefs loun d text d categorie) */}
                <h3
                  className="text-xs sm:text-[13px] font-extrabold leading-snug line-clamp-2 mt-auto tracking-tight"
                  style={{
                    color: isCodeUnavailable ? '#6B7280' : productDeptConfig.tagText,
                  }}
                  title={product.name}
                >
                  {product.name}
                </h3>
              </div>
            );
          })
        ) : (
          <div className="col-span-2 bg-white rounded-[16px] p-6 text-center border border-gray-100 shadow-2xs mt-3">
            <p className="text-xs font-bold text-[#171717]">
              {products.length === 0 ? 'Catalogue vide (0 produit)' : 'Aucun produit trouvé'}
            </p>
            <p className="text-[11px] text-[#333333] mt-0.5">
              {products.length === 0
                ? 'Tous les produits ont été retirés pour tester la base Supabase. Ajoutez un article depuis le panneau Admin ou depuis Supabase.'
                : activeQuery.trim()
                ? `Aucun résultat pour "${activeQuery.trim()}". Essayez avec un code court (2, 3 ou 4 chiffres) ou le nom de l'article.`
                : 'Aucun article dans cette catégorie pour le moment.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
