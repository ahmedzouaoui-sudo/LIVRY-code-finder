import React from 'react';
import { Minus, Plus } from 'lucide-react';
import { ProductUnitInfo, calculateTargetQuantity } from '../utils/productWeight';

interface QuantityCalculatorProps {
  unitInfo: ProductUnitInfo;
  multiplier: number;
  onMultiplierChange: (val: number) => void;
  onReset?: () => void;
}

export const QuantityCalculator: React.FC<QuantityCalculatorProps> = ({
  multiplier,
  onMultiplierChange,
}) => {

  const handleStep = (delta: number) => {
    const next = Math.max(1, Math.min(99, multiplier + delta));
    onMultiplierChange(next);
  };

  return (
    <div className="w-full my-2.5">
      {/* Ghir - digit + safe */}
      <div className="flex items-center justify-between gap-3 bg-white p-2 rounded-[16px] border border-[#E0E0E6] shadow-2xs">
        <button
          type="button"
          onClick={() => handleStep(-1)}
          disabled={multiplier <= 1}
          className="w-11 h-11 rounded-[12px] flex items-center justify-center text-white active:scale-90 disabled:opacity-30 transition shadow-xs cursor-pointer select-none shrink-0"
          style={{ backgroundColor: '#3D4853' }}
          aria-label="Diminuer"
        >
          <Minus className="w-5 h-5" />
        </button>

        <div className="text-center px-2 flex-1 select-none">
          <span className="text-2xl font-black text-[#171717] tracking-tight">
            {multiplier}
          </span>
        </div>

        <button
          type="button"
          onClick={() => handleStep(1)}
          disabled={multiplier >= 99}
          className="w-11 h-11 rounded-[12px] flex items-center justify-center text-white active:scale-90 transition shadow-xs cursor-pointer select-none shrink-0"
          style={{ backgroundColor: '#3D4853' }}
          aria-label="Augmenter"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
