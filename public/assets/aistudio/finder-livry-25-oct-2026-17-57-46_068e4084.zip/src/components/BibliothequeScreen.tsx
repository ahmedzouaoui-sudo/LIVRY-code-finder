import React from 'react';
import { ArrowLeft, Database } from 'lucide-react';
import { Department } from '../types';
import { useApp } from '../context/AppContext';

interface BibliothequeScreenProps {
  onBack: () => void;
  onSelectDepartment: (dept: Department) => void;
}

export const BibliothequeScreen: React.FC<BibliothequeScreenProps> = ({
  onBack,
  onSelectDepartment,
}) => {
  const { role, setActiveTab } = useApp();

  return (
    <div className="w-full max-w-[650px] mx-auto px-4 py-3 flex flex-col min-h-[calc(100vh-70px)]">
      {/* Back button at the top */}
      <div className="flex items-center justify-between gap-2 mb-4">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] text-[#0759A4] bg-white border border-[#E0E0E6]/80 shadow-2xs hover:bg-[#EBF4FC] active:scale-95 transition font-bold text-xs cursor-pointer select-none"
          aria-label="Retour à l'accueil"
        >
          <ArrowLeft className="w-4 h-4 text-[#0759A4]" />
          <span>Retour</span>
        </button>

        <h1 className="font-bold text-[#171717] text-sm sm:text-base text-center truncate">
          Bibliothèque des Rayons
        </h1>

        {role === 'Admin' ? (
          <button
            type="button"
            onClick={() => setActiveTab('admin')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-[12px] bg-[#FDF0F5] hover:bg-[#FCE4EC] text-[#B43167] border border-[#B43167]/30 text-xs font-black transition active:scale-95 cursor-pointer shadow-2xs select-none"
            title="Ouvrir le panneau Données & Base Supabase"
          >
            <Database className="w-3.5 h-3.5" />
            <span>Données Data</span>
          </button>
        ) : (
          <div className="w-16" />
        )}
      </div>

      {/* 2 x 2 Balanced Grid of Category Cards — 160 x 160 px with User Images */}
      <div className="flex-1 flex flex-col justify-center items-center my-auto py-2">
        <div className="grid grid-cols-2 gap-3.5 sm:gap-5 justify-items-center items-center">
          {/* 1. Boulangerie et pâtisserie (160 x 160 px) */}
          <button
            type="button"
            onClick={() => onSelectDepartment('Boulangerie et pâtisserie')}
            className="w-[160px] h-[160px] bg-[#F9A825] rounded-[16px] p-2.5 flex flex-col items-center justify-center text-center shadow-[0_4px_12px_rgba(249,168,37,0.2)] hover:scale-[1.02] active:scale-95 transition-all cursor-pointer select-none"
            style={{ width: '160px', height: '160px', backgroundColor: '#F9A825' }}
          >
            {/* Real Boulangerie Avatar Image */}
            <div className="w-[62px] h-[62px] mb-2 flex items-center justify-center shrink-0">
              <img
                src="/assets/aistudio/boulangerie_5c55e301.png"
                alt="Boulangerie et pâtisserie"
                className="w-full h-full object-contain drop-shadow-xs"
              />
            </div>
            <span className="text-[12px] font-bold text-[#FFFFFF] leading-snug line-clamp-2 px-1">
              Boulangerie et pâtisserie
            </span>
          </button>

          {/* 2. Fruits et légumes (160 x 160 px) */}
          <button
            type="button"
            onClick={() => onSelectDepartment('Fruits et légumes')}
            className="w-[160px] h-[160px] bg-[#155B48] rounded-[16px] p-2.5 flex flex-col items-center justify-center text-center shadow-[0_4px_12px_rgba(21,91,72,0.2)] hover:scale-[1.02] active:scale-95 transition-all cursor-pointer select-none"
            style={{ width: '160px', height: '160px', backgroundColor: '#155B48' }}
          >
            {/* Real Marché (Fruits & Légumes) Avatar Image */}
            <div className="w-[62px] h-[62px] mb-2 flex items-center justify-center shrink-0">
              <img
                src="/assets/aistudio/marche_ce5915e1.png"
                alt="Fruits et légumes"
                className="w-full h-full object-contain drop-shadow-xs"
              />
            </div>
            <span className="text-[12px] font-bold text-[#FFFFFF] leading-snug line-clamp-2 px-1">
              Fruits et légumes
            </span>
          </button>

          {/* 3. Boucherie et volaille (160 x 160 px) */}
          <button
            type="button"
            onClick={() => onSelectDepartment('Boucherie et volaille')}
            className="w-[160px] h-[160px] bg-[#B93838] rounded-[16px] p-2.5 flex flex-col items-center justify-center text-center shadow-[0_4px_12px_rgba(185,56,56,0.2)] hover:scale-[1.02] active:scale-95 transition-all cursor-pointer select-none"
            style={{ width: '160px', height: '160px', backgroundColor: '#B93838' }}
          >
            {/* Real Stand Boucherie Avatar Image */}
            <div className="w-[62px] h-[62px] mb-2 flex items-center justify-center shrink-0">
              <img
                src="/assets/aistudio/stand_boucherie_bf941158.png"
                alt="Boucherie et volaille"
                className="w-full h-full object-contain drop-shadow-xs"
              />
            </div>
            <span className="text-[12px] font-bold text-[#FFFFFF] leading-snug line-clamp-2 px-1">
              Boucherie et volaille
            </span>
          </button>

          {/* 4. Fromage et charcuterie (160 x 160 px) */}
          <button
            type="button"
            onClick={() => onSelectDepartment('Fromage et charcuterie')}
            className="w-[160px] h-[160px] bg-[#FFF3CD] rounded-[16px] p-2.5 flex flex-col items-center justify-center text-center shadow-[0_4px_12px_rgba(7,87,166,0.06)] hover:scale-[1.02] active:scale-95 transition-all cursor-pointer select-none border border-[#FFE699]/60"
            style={{ width: '160px', height: '160px', backgroundColor: '#FFF3CD' }}
          >
            {/* Real Fromage Avatar Image */}
            <div className="w-[62px] h-[62px] mb-2 flex items-center justify-center shrink-0">
              <img
                src="/assets/aistudio/fromage_7269f926.png"
                alt="Fromage et charcuterie"
                className="w-full h-full object-contain drop-shadow-xs"
              />
            </div>
            <span className="text-[12px] font-bold text-[#0757A6] leading-snug line-clamp-2 px-1">
              Fromage et charcuterie
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
