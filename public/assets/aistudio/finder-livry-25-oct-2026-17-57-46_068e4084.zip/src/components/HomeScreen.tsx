import React, { useRef } from 'react';
import { Search, Lightbulb, Database, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const HomeScreen: React.FC = () => {
  const { searchQuery, setSearchQuery, setActiveTab, role, products } = useApp();
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="w-full flex-1 flex flex-col justify-between max-w-[650px] mx-auto px-4 py-6 min-h-[calc(100vh-65px)]">
      {/* Spacer to balance layout vertically */}
      <div className="flex-1" />

      {/* Main Search Bar Area */}
      <div className="w-full max-w-[650px] mx-auto flex flex-col items-center my-auto">
        {/* Brand Banner Above Search Bar */}
        <div className="w-full flex items-center justify-center mb-5 sm:mb-8 px-4">
          <img
            src="/assets/aistudio/barre_de_recherch_a0bb2929.png"
            alt="Aswak Assalam, Livry, Marjane"
            className="w-auto h-16 sm:h-22 max-w-[90%] sm:max-w-[440px] object-contain select-none pointer-events-none drop-shadow-xs"
          />
        </div>

        <div
          onClick={() => inputRef.current?.focus()}
          className="w-full max-w-[650px] h-[76px] sm:h-[90px] bg-[#FFFFFF] rounded-[20px] shadow-[0_4px_16px_rgba(7,89,164,0.08)] border border-[#E0E0E6]/90 flex items-center px-5 transition-all focus-within:border-[#0759A4] focus-within:ring-3 focus-within:ring-[#0759A4]/15 cursor-text"
        >
          {/* Search Icon aligned inside the field */}
          <Search className="w-6 h-6 sm:w-8 sm:h-8 text-[#171717] shrink-0 mr-3.5" />

          {/* Search Input (Responsive Bold Text) */}
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Code (2, 3, 4 chiffres) ou nom..."
            className="w-full h-full bg-transparent border-none outline-none text-[#171717] font-bold text-[18px] sm:text-[24px] placeholder:text-gray-400 placeholder:font-bold"
            autoFocus={false}
          />
        </div>
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Bottom Navigation */}
      <div className="w-full max-w-[650px] mx-auto pt-4 pb-2 space-y-2.5">
        {/* Bouton direct vers les Données si connecté en Admin */}
        {role === 'Admin' && (
          <button
            type="button"
            onClick={() => setActiveTab('admin')}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-[#B43167] via-[#942353] to-[#7B1D45] text-white rounded-[18px] sm:rounded-[20px] shadow-[0_4px_16px_rgba(180,49,103,0.28)] hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-between cursor-pointer select-none border border-white/20"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-[12px] bg-white/20 flex items-center justify-center shrink-0">
                <Database className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <div className="font-black text-sm sm:text-base leading-tight">
                  Panneau Données & Base (Admin)
                </div>
                <div className="text-[11px] text-pink-100 font-medium">
                  Tableur CSV 11 colonnes, Supabase & {products.length} articles
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 bg-white text-[#B43167] font-black text-xs px-3 py-1.5 rounded-[12px] shadow-xs shrink-0">
              <span>Ouvrir Data</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        )}

        <button
          type="button"
          onClick={() => setActiveTab('library')}
          className="w-full h-[54px] sm:h-[60px] bg-[#0759A4] text-[#FFFFFF] rounded-[18px] sm:rounded-[20px] font-bold text-base sm:text-lg shadow-[0_4px_14px_rgba(7,89,164,0.22)] hover:bg-[#064a88] active:scale-[0.98] transition-all flex items-center justify-center cursor-pointer select-none"
        >
          Bibliothèque
        </button>

        {/* Bouton Astuces taht bibliotheque */}
        <button
          type="button"
          onClick={() => setActiveTab('tips')}
          className="w-full h-[50px] sm:h-[54px] bg-[#FFFFFF] border-2 border-[#0759A4]/25 text-[#0759A4] hover:bg-[#EBF4FC]/60 rounded-[18px] sm:rounded-[20px] font-bold text-sm sm:text-base shadow-2xs active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer select-none"
        >
          <Lightbulb className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span>Astuces & Tutos</span>
        </button>
      </div>
    </div>
  );
};
