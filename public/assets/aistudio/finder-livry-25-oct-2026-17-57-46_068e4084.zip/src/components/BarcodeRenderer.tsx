import React, { useRef, useState } from 'react';
import { Copy, Check, Maximize2, Minimize2 } from 'lucide-react';
import { encodeEan13, encodeEan8, formatBarcodeDigits } from '../utils/barcode';

interface BarcodeRendererProps {
  code: string;
  format?: 'EAN-13' | 'EAN-8';
  height?: number;
  barWidth?: number;
  showText?: boolean;
  onCopy?: () => void;
  className?: string;
}

export const BarcodeRenderer: React.FC<BarcodeRendererProps> = ({
  code,
  format = code.length <= 8 ? 'EAN-8' : 'EAN-13',
  height = 95,
  barWidth = 2.4,
  showText = true,
  onCopy,
  className = '',
}) => {
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Encode
  const isEan8 = format === 'EAN-8' || code.length === 8;
  const ean13Data = !isEan8 ? encodeEan13(code) : null;
  const ean8Data = isEan8 ? encodeEan8(code) : null;
  const modules = ean8Data ? ean8Data.modules : ean13Data!.modules;

  const quietZoneModules = 10;
  const totalModules = modules.length + quietZoneModules * 2;
  const svgWidth = totalModules * barWidth;
  const guardExtraHeight = 12;
  const standardBarHeight = height;
  const guardBarHeight = standardBarHeight + guardExtraHeight;
  const totalSvgHeight = guardBarHeight + (showText ? 28 : 6);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    setCopied(true);
    if (onCopy) onCopy();
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleFullscreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFullscreen(!isFullscreen);
  };

  const formattedDigits = formatBarcodeDigits(code);

  const barcodeContent = (
    <div
      ref={containerRef}
      className={`relative flex flex-col items-center bg-white p-4 rounded-xl border border-gray-100 shadow-inner ${
        isFullscreen ? 'fixed inset-0 z-50 flex items-center justify-center p-6 bg-white/95 backdrop-blur-md' : ''
      } ${className}`}
    >
      {/* Top action buttons (right-aligned, no title) */}
      <div className="w-full flex justify-end items-center mb-1 px-1">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={toggleFullscreen}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition"
            title={isFullscreen ? 'Quitter plein écran' : 'Scanner plein écran (Caisse)'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition ${
              copied
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
            title="Copier le code-barres"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Copié !</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copier</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* SVG Barcode Graphic */}
      <div className="overflow-x-auto max-w-full flex justify-center py-2 bg-white rounded-lg select-none">
        <svg
          width={isFullscreen ? svgWidth * 1.35 : svgWidth}
          height={isFullscreen ? totalSvgHeight * 1.35 : totalSvgHeight}
          viewBox={`0 0 ${svgWidth} ${totalSvgHeight}`}
          className="shape-rendering-crispEdges transition-transform"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* White Background for Quiet Zones */}
          <rect x="0" y="0" width={svgWidth} height={totalSvgHeight} fill="#FFFFFF" />

          {/* First Digit Outside for EAN-13 */}
          {!isEan8 && showText && ean13Data && (
            <text
              x={quietZoneModules * barWidth - 10}
              y={standardBarHeight + 20}
              fontSize="16"
              fontWeight="bold"
              fontFamily="monospace"
              fill="#1F2937"
              textAnchor="end"
            >
              {ean13Data.firstDigit}
            </text>
          )}

          {/* Module Bars */}
          {modules.map((m, idx) => {
            if (m.bit === '0') return null;
            const x = (quietZoneModules + idx) * barWidth;
            const barH = m.isGuard ? guardBarHeight : standardBarHeight;
            return (
              <rect
                key={idx}
                x={x}
                y={6}
                width={barWidth}
                height={barH}
                fill="#000000"
              />
            );
          })}

          {/* Bottom Human-Readable Text */}
          {showText && (
            <>
              {isEan8 && ean8Data ? (
                <>
                  <text
                    x={(quietZoneModules + 16) * barWidth}
                    y={standardBarHeight + 20}
                    fontSize="15"
                    fontWeight="bold"
                    fontFamily="monospace"
                    fill="#1F2937"
                    textAnchor="middle"
                  >
                    {ean8Data.leftText}
                  </text>
                  <text
                    x={(quietZoneModules + 48) * barWidth}
                    y={standardBarHeight + 20}
                    fontSize="15"
                    fontWeight="bold"
                    fontFamily="monospace"
                    fill="#1F2937"
                    textAnchor="middle"
                  >
                    {ean8Data.rightText}
                  </text>
                </>
              ) : ean13Data ? (
                <>
                  <text
                    x={(quietZoneModules + 24) * barWidth}
                    y={standardBarHeight + 20}
                    fontSize="15"
                    fontWeight="bold"
                    fontFamily="monospace"
                    fill="#1F2937"
                    textAnchor="middle"
                  >
                    {ean13Data.leftText}
                  </text>
                  <text
                    x={(quietZoneModules + 70) * barWidth}
                    y={standardBarHeight + 20}
                    fontSize="15"
                    fontWeight="bold"
                    fontFamily="monospace"
                    fill="#1F2937"
                    textAnchor="middle"
                  >
                    {ean13Data.rightText}
                  </text>
                </>
              ) : null}
            </>
          )}
        </svg>
      </div>

      {/* Formatted Full Monospace Code */}
      <div className="mt-2 text-center">
        <span className="font-mono text-base font-bold tracking-widest text-gray-900 bg-gray-50 px-3 py-1 rounded-md border border-gray-200">
          {formattedDigits}
        </span>
      </div>

      {isFullscreen && (
        <div className="mt-6 flex flex-col items-center gap-2">
          <p className="text-sm font-medium text-gray-700 bg-amber-50 text-amber-900 px-4 py-2 rounded-xl border border-amber-200">
            Scanner maintenant avec la douchette de caisse Marjane
          </p>
          <button
            type="button"
            onClick={toggleFullscreen}
            className="px-6 py-2.5 bg-[#B43167] text-white text-sm font-semibold rounded-xl shadow-md hover:bg-[#972251] transition"
          >
            Fermer le plein écran
          </button>
        </div>
      )}
    </div>
  );

  return barcodeContent;
};
