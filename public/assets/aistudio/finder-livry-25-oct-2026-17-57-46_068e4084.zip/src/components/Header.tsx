import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Lock, X, ShieldAlert, RefreshCw, Database, Shield } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';

export const Header: React.FC<{ onLogoClick?: () => void }> = ({ onLogoClick }) => {
  const {
    role,
    setRole,
    activeTab,
    setActiveTab,
    setSelectedDepartment,
    showToast,
    syncWithSupabase,
    isSyncing,
    products,
    lastSyncTimestamp,
  } = useApp();
  const [isRoleOpen, setIsRoleOpen] = useState(false);
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [adminPin, setAdminPin] = useState('');
  const [pinError, setPinError] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const pinInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsRoleOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  useEffect(() => {
    if (isPinModalOpen) {
      setTimeout(() => {
        pinInputRef.current?.focus();
      }, 100);
    } else {
      setAdminPin('');
      setPinError(false);
    }
  }, [isPinModalOpen]);

  const roleStyles: Record<Role, { label: string; color: string; bg: string }> = {
    Pickeur: { label: 'Pickeur', color: '#0759A4', bg: '#EBF4FC' },
    Livreur: { label: 'Livreur', color: '#28B873', bg: '#EAF8F1' },
    Admin: { label: 'Admin', color: '#B43167', bg: '#FDF0F5' },
  };

  const current = roleStyles[role];

  const handleRoleSelect = (targetRole: Role) => {
    setIsRoleOpen(false);
    if (targetRole === role) return;

    if (targetRole === 'Admin') {
      setIsPinModalOpen(true);
    } else {
      setRole(targetRole);
    }
  };

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPin === '1997') {
      setRole('Admin');
      setIsPinModalOpen(false);
      setAdminPin('');
      setPinError(false);
      showToast('Accès Administrateur déverrouillé');
    } else {
      setPinError(true);
      setAdminPin('');
      pinInputRef.current?.focus();
    }
  };

  return (
    <>
      <header className="w-full bg-[#FFFFFF] border-b border-[#E0E0E6]/60 sticky top-0 z-30 shadow-[0_2px_6px_rgba(0,0,0,0.03)] px-3.5 py-2">
        <div className="max-w-[750px] mx-auto flex items-center justify-between gap-2">
          {/* Application logo aligned to the left */}
          <div
            onClick={() => {
              if (onLogoClick) onLogoClick();
              else {
                setSelectedDepartment(null);
                setActiveTab('home');
              }
            }}
            className="flex items-center gap-2.5 cursor-pointer select-none group min-w-0"
          >
            <div className="w-[36px] h-[36px] rounded-full bg-white flex items-center justify-center p-0.5 shadow-2xs border border-gray-100 group-hover:scale-105 transition-transform shrink-0">
              <img
                src="/assets/aistudio/icon_03400f86.png"
                alt="Livry Code Finder"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex flex-col truncate">
              <div className="flex items-center gap-1 leading-none">
                <span className="text-[16px] sm:text-[17px] font-black tracking-tight text-[#0759A4]">
                  Livry
                </span>
                <span className="text-[10px] sm:text-[11px] font-extrabold text-[#171717] tracking-wider uppercase">
                  CODE FINDER
                </span>
              </div>
              <span className="text-[9px] font-medium text-[#757575] tracking-wide mt-0.5 hidden xs:inline sm:inline">
                Marjane & Aswak Assalam
              </span>
            </div>
          </div>

          {/* Right Header Area: "Mise à jour" Button + Role Switcher Pill */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Bouton Mise à jour (demandé pour Pickeur / Livreur) */}
            <button
              type="button"
              onClick={() => syncWithSupabase(true)}
              disabled={isSyncing}
              title={lastSyncTimestamp ? `${lastSyncTimestamp} - Cliquez pour forcer la mise à jour` : 'Mettre à jour le catalogue depuis la base de données'}
              className="flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1 rounded-[12px] bg-[#0759A4]/10 hover:bg-[#0759A4]/15 active:bg-[#0759A4]/20 text-[#0759A4] border border-[#0759A4]/25 text-[11px] font-bold transition shadow-2xs active:scale-95 cursor-pointer disabled:opacity-60 select-none"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 shrink-0 ${isSyncing ? 'animate-spin text-[#0759A4]' : 'text-[#0759A4]'}`}
              />
              <span className="inline font-bold">
                {isSyncing ? 'Màj...' : 'Mise à jour'}
              </span>
              <span
                className="inline-flex items-center justify-center min-w-[18px] h-[17px] px-1 rounded-full bg-white text-[#0759A4] font-black text-[9px] shadow-2xs border border-[#0759A4]/20"
                title={`${products.length} articles disponibles`}
              >
                {products.length}
              </span>
            </button>

            {/* Bouton direct "Données / Data" quand on est connecté en Admin */}
            {role === 'Admin' && (
              <button
                type="button"
                onClick={() => {
                  setSelectedDepartment(null);
                  setActiveTab('admin');
                  showToast('Ouverture du panneau Données & Base...');
                }}
                title="Accéder directement au panneau Données, Tableur CSV et Base Supabase"
                className={`flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1 rounded-[12px] font-black text-[11px] transition shadow-2xs active:scale-95 cursor-pointer select-none border ${
                  activeTab === 'admin'
                    ? 'bg-[#B43167] text-white border-[#B43167] shadow-xs ring-2 ring-[#B43167]/30'
                    : 'bg-[#FDF0F5] hover:bg-[#FCE4EC] text-[#B43167] border-[#B43167]/30 hover:border-[#B43167]'
                }`}
              >
                <Database className={`w-3.5 h-3.5 shrink-0 ${activeTab === 'admin' ? 'text-white' : 'text-[#B43167]'}`} />
                <span className="inline font-black tracking-tight">
                  Données Data
                </span>
                <span
                  className={`inline-flex items-center justify-center min-w-[18px] h-[17px] px-1 rounded-full font-black text-[9px] ${
                    activeTab === 'admin'
                      ? 'bg-white/20 text-white'
                      : 'bg-white text-[#B43167] shadow-2xs border border-[#B43167]/20'
                  }`}
                >
                  {products.length}
                </span>
              </button>
            )}

            {/* Role Switcher Pill */}
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setIsRoleOpen(!isRoleOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-[12px] border text-[11px] font-bold transition shadow-2xs active:scale-95 cursor-pointer"
                style={{
                  backgroundColor: current.bg,
                  color: current.color,
                  borderColor: `${current.color}35`,
                }}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: current.color }}
                />
                <span>{current.label}</span>
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>

              {isRoleOpen && (
                <div className="absolute right-0 mt-1.5 w-44 bg-white rounded-[14px] shadow-xl border border-gray-100 py-1 z-50 animate-in fade-in zoom-in-95 duration-100">
                  {(['Pickeur', 'Livreur', 'Admin'] as Role[]).map((r) => {
                    const item = roleStyles[r];
                    return (
                      <button
                        key={r}
                        type="button"
                        onClick={() => handleRoleSelect(r)}
                        className="w-full flex items-center justify-between px-3 py-2 text-xs font-semibold hover:bg-gray-50 transition cursor-pointer"
                        style={{ color: role === r ? item.color : '#333333' }}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: item.color }}
                          />
                          <span>{item.label}</span>
                          {r === 'Admin' && role !== 'Admin' && (
                            <Lock className="w-3 h-3 text-[#B43167] opacity-80" />
                          )}
                        </div>
                        {role === r && <span className="text-[10px] font-bold">✓</span>}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Admin Password Prompt Modal (Strictly Masked - 1997) */}
      {isPinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-xs bg-white rounded-[22px] p-5 shadow-2xl border border-gray-200 animate-in zoom-in-95 duration-150 relative">
            <button
              type="button"
              onClick={() => setIsPinModalOpen(false)}
              className="absolute top-3.5 right-3.5 p-1 text-gray-400 hover:text-gray-600 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-[#FDF0F5] border border-[#B43167]/20 flex items-center justify-center text-[#B43167] mb-3">
                <Lock className="w-5 h-5" />
              </div>

              <h3 className="text-sm font-bold text-[#171717]">Accès Section Admin</h3>
              <p className="text-[11px] text-gray-500 mt-1 mb-4">
                Veuillez saisir le code confidentiel administrateur pour continuer.
              </p>

              <form onSubmit={handleVerifyPin} className="w-full space-y-3">
                <div>
                  <input
                    ref={pinInputRef}
                    type="password"
                    inputMode="numeric"
                    autoComplete="current-password"
                    maxLength={10}
                    value={adminPin}
                    onChange={(e) => {
                      setAdminPin(e.target.value);
                      if (pinError) setPinError(false);
                    }}
                    placeholder="••••"
                    className={`w-full text-center text-lg tracking-[0.4em] font-bold py-2.5 px-3 rounded-[14px] border ${
                      pinError
                        ? 'border-rose-500 bg-rose-50/50 text-rose-700'
                        : 'border-gray-200 focus:border-[#B43167] bg-gray-50/60'
                    } outline-none transition`}
                  />
                  {pinError && (
                    <div className="flex items-center justify-center gap-1 mt-2 text-rose-600 text-[11px] font-bold">
                      <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                      <span>Code d'accès incorrect</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsPinModalOpen(false)}
                    className="py-2 px-3 rounded-[12px] border border-gray-200 text-xs font-bold text-gray-600 hover:bg-gray-50 cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={!adminPin.trim()}
                    className="py-2 px-3 rounded-[12px] bg-[#B43167] hover:bg-[#992655] text-white text-xs font-bold shadow-xs active:scale-95 transition cursor-pointer disabled:opacity-40"
                  >
                    Valider
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
