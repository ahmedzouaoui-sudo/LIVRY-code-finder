import { Product } from "../types";

export const INITIAL_PRODUCTS: Product[] = [
  {
    "id": 1,
    "code": "6037",
    "name": "Beefsteak de bœuf 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2600488005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729518809/product/825b983bad64b907fe7503cde8441f38.webp",
    "isEnabled": true
  },
  {
    "id": 2,
    "code": "7989",
    "name": "Brochettes de bœuf 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2602042005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743685259/product/5328ed5ea04a4b9c65ce519a2b4a019a.webp",
    "isEnabled": true
  },
  {
    "id": 3,
    "code": "-",
    "name": "Brochettes de bœuf aux trois poivres 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729518558/product/75fd907780636a3bb27d725ed7e0063a.webp",
    "isEnabled": true
  },
  {
    "id": 4,
    "code": "-",
    "name": "Brochettes de bœuf marinées au thym romarin 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781002981/product/7d5f769b24b94aa2d6eaf9477fb1f98c.webp",
    "isEnabled": true
  },
  {
    "id": 5,
    "code": "-",
    "name": "Brochettes de bœuf rouge marinées 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMarjane": "2602042005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1666273689/product_optimized/d28d3104d7882798d30982d057a26582.webp",
    "isEnabled": true
  },
  {
    "id": 6,
    "code": "-",
    "name": "Cervelle d'agneau à la pièce",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588258605/product_optimized/d29eefd634f09c7028f99249294b71d0.webp",
    "isEnabled": true
  },
  {
    "id": 7,
    "code": "-",
    "name": "Cervelle de bœuf à la pièce",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588258724/product_optimized/3f87bf8332e9c433f95bcf3e6275b72b.webp",
    "isEnabled": true
  },
  {
    "id": 8,
    "code": "4271",
    "name": "Côte de bœuf 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2600943005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683662/product/5fe83c8f8444aa44e45ec801c4a91a69.webp",
    "isEnabled": true
  },
  {
    "id": 9,
    "code": "5545",
    "name": "Côtelette filet d'agneau 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2619816005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587303926/product_optimized/2bcb2077f1357292acb3ac563cab5be5.webp",
    "isEnabled": true
  },
  {
    "id": 10,
    "code": "XXXX",
    "name": "Demi douarad d’agneau à la pièce",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMarjane": "2651511000010",
    "isEnabled": true
  },
  {
    "id": 11,
    "code": "5809",
    "name": "Deux steaks hachés de bœuf maigre 250g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2619754002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1748966465/product/f4dfabbb76cf4d211ab33bc6015d137a.webp",
    "isEnabled": true
  },
  {
    "id": 12,
    "code": "6032",
    "name": "Émincé de bœuf nature 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2600477005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1749035471/product/9ad7a918d53c5f65797ef69f8e7a5ec3.webp",
    "isEnabled": true
  },
  {
    "id": 13,
    "code": "4248",
    "name": "Emincé de bœuf rouge mariné 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2609701005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1666274785/product_optimized/4a9302e2a75bd914029d793b3e0d6568.webp",
    "isEnabled": true
  },
  {
    "id": 14,
    "code": "2155",
    "name": "Émincé de bœuf rouge mariné au thym et romarin 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2605562005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744875432/product/81ccbff06753a42b9fde8333d6039724.webp",
    "isEnabled": true
  },
  {
    "id": 15,
    "code": "8034",
    "name": "Epaule d'agneau à la découpe 1Kg",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2619088010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743684497/product/a1a42ac1f3538121c8c239d953a9b10d.webp",
    "isEnabled": true
  },
  {
    "id": 16,
    "code": "6650",
    "name": "Epaule de bœuf avec os 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2608521005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683797/product/a84d2bb98cc3441740afb686b5cbeb42.webp",
    "isEnabled": true
  },
  {
    "id": 17,
    "code": "-",
    "name": "Epaule entière d'agneau 1Kg",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587303798/product_optimized/7fc13f621b726e798ba428448894a649.webp",
    "isEnabled": true
  },
  {
    "id": 18,
    "code": "1409",
    "name": "Faux filet de bœuf 250g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2608806002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729518894/product/79b729e4f45c064164aaf487adc3ad4f.webp",
    "isEnabled": true
  },
  {
    "id": 19,
    "code": "6040",
    "name": "Filet de bœuf 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2601115005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729518961/product/8f3f966651d9aab44c8a77df5cc12893.webp",
    "isEnabled": true
  },
  {
    "id": 20,
    "code": "1500",
    "name": "Foie et cœur de bœuf 200g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2654236002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1732790631/product/2085f97f0f5af0c579d181ba8c9bff79.webp",
    "isEnabled": true
  },
  {
    "id": 21,
    "code": "-",
    "name": "Gigot d'agneau 1Kg",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587304036/product_optimized/ac44da76cd6724e92f0d07ff4a5474e5.webp",
    "isEnabled": true
  },
  {
    "id": 22,
    "code": "6052",
    "name": "Jarret de bœuf avec os 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2601180005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729519064/product/801b7fdf49b243de959a99e4c865dc3f.webp",
    "isEnabled": true
  },
  {
    "id": 23,
    "code": "6047",
    "name": "Jarret de bœuf sans os 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2601118005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729519130/product/4a678f432cb897da47faa10c22ef3b06.webp",
    "isEnabled": true
  },
  {
    "id": 24,
    "code": "-",
    "name": "Langue de bœuf 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMiniSecours": "22812575",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1768474801/product/bf4705507f3e3bc14b199ae4d0b94e42.webp",
    "isEnabled": true
  },
  {
    "id": 25,
    "code": "3861",
    "name": "Merguez de bœuf 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2608953005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1760370279/product/2211ba66459a781ef7448f99e26c518a.webp",
    "isEnabled": true
  },
  {
    "id": 26,
    "code": "-",
    "name": "Merguez de bœuf cocktail 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744816375/product/5fadfec5c133a44a828b086725aef834.webp",
    "isEnabled": true
  },
  {
    "id": 27,
    "code": "-",
    "name": "Ris de bœuf 250g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeSecours": "2000014562370",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1732789155/product/76f46116e18f96af655acc03c41a4583.webp",
    "isEnabled": true
  },
  {
    "id": 28,
    "code": "9924",
    "name": "Saucisses 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2612222005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587306611/product_optimized/69dc5afea40fed1291eec84d92b5757e.webp",
    "isEnabled": true
  },
  {
    "id": 29,
    "code": "1758",
    "name": "Saucisses de bœuf aux fines herbes environ 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2606608005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587306024/product_optimized/7419427e87e2f0c5839d637d7e9a1525.webp",
    "isEnabled": true
  },
  {
    "id": 30,
    "code": "-",
    "name": "Saucisses de bœuf piquantes 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587306238/product_optimized/c87431eb9c2aa859dc5f2b7ffe8f35e2.webp",
    "isEnabled": true
  },
  {
    "id": 31,
    "code": "-",
    "name": "Steak de rumsteak 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1749035822/product/a04f811a45b10c87c869f8d9b61b8722.webp",
    "isEnabled": true
  },
  {
    "id": 32,
    "code": "6056",
    "name": "Tagine de bœuf avec os 1kg",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2601174010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683955/product/76809a925dc5c87558d9e45a35aedc97.webp",
    "isEnabled": true
  },
  {
    "id": 33,
    "code": "6056",
    "name": "Tagine de bœuf avec os 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2601174005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683893/product/e73a94cfa9cae4ebd33aa81869348766.webp",
    "isEnabled": true
  },
  {
    "id": 34,
    "code": "5526",
    "name": "Viande hachée de bœuf 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2619574005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1748965831/product/d128d6f6d2673859b354146ab77736fa.webp",
    "isEnabled": true
  },
  {
    "id": 35,
    "code": "1700",
    "name": "Viande hachée maigre de bœuf 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2640895005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756114904/product/085d50efea70ee1346a8c1779a402025.webp",
    "isEnabled": true
  },
  {
    "id": 36,
    "code": "-",
    "name": "Viande tagine de bœuf avec os 500g",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1665054665/product_optimized/7f9457755959c381b704a0147b823db7.webp",
    "isEnabled": true
  },
  {
    "id": 37,
    "code": "-",
    "name": "Viande tagine de bœuf sans os 1Kg - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMarjane": "2601177010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1748722471/product/e57b128f0e0f415289f00aa75bc24aa3.webp",
    "isEnabled": true
  },
  {
    "id": 38,
    "code": "6054",
    "name": "Viande tagine de bœuf sans os 500g - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Viandes",
    "barcodeMjValide": "2601177005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1741263363/product/1ed0f6cdb58ae104ef69b2e52b06f82d.webp",
    "isEnabled": true
  },
  {
    "id": 39,
    "code": "1350",
    "name": "Aileron de dinde 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610104005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781863416/product/ae85bebd918cd497557f27303aab7e52.webp",
    "isEnabled": true
  },
  {
    "id": 40,
    "code": "1451",
    "name": "Ailes de poulet 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610176005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744276116/product/84309987c7895cc57cba2f3e9f1ac5f6.webp",
    "isEnabled": true
  },
  {
    "id": 41,
    "code": "2308",
    "name": "Boulette de poulet farcie 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2609099002000",
    "barcodeSecours": "2000014287907",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642457831/product_optimized/f893c1a71662216d8730abeb7a7564b4.webp",
    "isEnabled": true
  },
  {
    "id": 42,
    "code": "5023",
    "name": "Brochette de filet de poulet 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2623140002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744297839/product/9e4d3345cc354014dabadb9e9338691a.webp",
    "isEnabled": true
  },
  {
    "id": 43,
    "code": "-",
    "name": "Brochettes blanches de dinde 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610108002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781864183/product/ab4721a0a0f05cfefd1daae37d575bcf.webp",
    "isEnabled": true
  },
  {
    "id": 44,
    "code": "1355",
    "name": "Brochettes de Filet de Dinde 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610108005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756475430/product/ba07573d2e4f4d1c1ff5d3d07727da98.webp",
    "isEnabled": true
  },
  {
    "id": 45,
    "code": "7676",
    "name": "Brochettes de filets de dinde mariné 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2606478002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683296/product/fa018879c38406eb42100ec6d8fe78f9.webp",
    "isEnabled": true
  },
  {
    "id": 46,
    "code": "7664",
    "name": "Brochettes filets de poulet mariné 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2653197002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743682901/product/e77b9f29463d7d58cb27dd1776308ed4.webp",
    "isEnabled": true
  },
  {
    "id": 47,
    "code": "1356",
    "name": "Brochettes rouges de dinde 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610109002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744299862/product/a5533327beef862ecf314c24534f3561.webp",
    "isEnabled": true
  },
  {
    "id": 48,
    "code": "4763",
    "name": "Burger de poulet au fromage 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2676541002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642458091/product_optimized/2d1a2ec4188b40516cfc9aec717fc9ac.webp",
    "isEnabled": true
  },
  {
    "id": 49,
    "code": "7851",
    "name": "Caille 3 unités",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2654379000017",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751456591/product/f8ff4621c3f3f50891ee0ef6f20e683e.webp",
    "isEnabled": true
  },
  {
    "id": 50,
    "code": "-",
    "name": "Caille 6 unités",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751456744/product/5ba787b53cc6058b96ad4e144a421133.webp",
    "isEnabled": true
  },
  {
    "id": 51,
    "code": "-",
    "name": "Canard entier prêt à cuire environ 3,5Kg",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781771224/product/acb85d9d7b9ba301d807c05028f57dfa.webp",
    "isEnabled": true
  },
  {
    "id": 52,
    "code": "-",
    "name": "Canard environ 1Kg",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751457160/product/379408d8ebecf5027fb82c1d657527b4.webp",
    "isEnabled": true
  },
  {
    "id": 53,
    "code": "4761",
    "name": "Chich kebab marocain 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2678321002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781864443/product/2368c84fae4c58ffca672eb8ca2bd5b5.webp",
    "isEnabled": true
  },
  {
    "id": 54,
    "code": "-",
    "name": "Chipolata de poulet 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781864649/product/6ff52cdb5dd7f7fabcf180904a39f227.webp",
    "isEnabled": true
  },
  {
    "id": 55,
    "code": "-",
    "name": "Cocktail de poulet 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781865002/product/50f3a5454801550be443ee971088c471.webp",
    "isEnabled": true
  },
  {
    "id": 56,
    "code": "8475",
    "name": "Coquelet Fermier 2 pièces",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2608810010000",
    "barcodeSecours": "2000014744509",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751457451/product/00294c2be78caf2575a691447a13f872.webp",
    "isEnabled": true
  },
  {
    "id": 57,
    "code": "-",
    "name": "Coquelet x2 (environ 600g)",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMarjane": "2630485000011",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1745320897/product/dff11997c9dfd63a233e7df6d8b26796.webp",
    "isEnabled": true
  },
  {
    "id": 58,
    "code": "3360",
    "name": "Coquelet x2 pièces - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2634617000010",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729100450/product/c72d3d8dded5193177cf1df01179443b.webp",
    "isEnabled": true
  },
  {
    "id": 59,
    "code": "9921",
    "name": "Cordon bleu 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2606912002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683455/product/aaf20b0b3bd66df9b5adeebc123984dd.webp",
    "isEnabled": true
  },
  {
    "id": 60,
    "code": "-",
    "name": "Cuisse crue de canard à la pièce",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1767090216/product/3f79aafdf05e278ba9e5fcde1c1b49c0.webp",
    "isEnabled": true
  },
  {
    "id": 61,
    "code": "1452",
    "name": "Cuisse de poulet 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610177005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1749642968/product/d5fe43c16f60ab6da70bfc374e3c5685.webp",
    "isEnabled": true
  },
  {
    "id": 62,
    "code": "2798",
    "name": "Émincé de dinde 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMarjane": "2665197002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744298169/product/90df81445f6498688d16ea41f7611735.webp",
    "isEnabled": true
  },
  {
    "id": 63,
    "code": "1459",
    "name": "Émincé de poulet 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610183002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744297315/product/a8947cf18368b219c7ef4740ff1802ba.webp",
    "isEnabled": true
  },
  {
    "id": 64,
    "code": "7668",
    "name": "Emincés de poulet marinés environ 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2635864002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743683095/product/dd71fded433303dfbc6f46eb82c0fbfc.webp",
    "isEnabled": true
  },
  {
    "id": 65,
    "code": "1354",
    "name": "Escalope de dinde 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMarjane": "2610107002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744050285/product/e63d6a58d5f8f47a03e4878fbcbdf8cb.webp",
    "isEnabled": true
  },
  {
    "id": 66,
    "code": "1943",
    "name": "Escalope de poulet croustillant fromage 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2690870002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642457751/product_optimized/0afc219f1fa598bc701136f0362c2f96.webp",
    "isEnabled": true
  },
  {
    "id": 67,
    "code": "-",
    "name": "Escalope de poulet croustillant piquant 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMarjane": "2608761002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642457670/product_optimized/1f0649888dc82669bb087b86bef5bc85.webp",
    "isEnabled": true
  },
  {
    "id": 68,
    "code": "1345",
    "name": "Filet de Dinde 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610100005000",
    "isEnabled": true
  },
  {
    "id": 69,
    "code": "5023",
    "name": "Filet de poulet 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2623140002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587294832/product_optimized/6ce5b847ed8fc59fc76e574fb13ca2fd.webp",
    "isEnabled": true
  },
  {
    "id": 70,
    "code": "-",
    "name": "Filets de dinde 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587296392/product_optimized/77ca3c2c976b183dab0d545b56bba057.webp",
    "isEnabled": true
  },
  {
    "id": 71,
    "code": "6585",
    "name": "Fingers fromage 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2678514002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781865447/product/34adfc86201274b1a8f190978e51ab13.webp",
    "isEnabled": true
  },
  {
    "id": 72,
    "code": "4931",
    "name": "Fingers fumé 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2674581002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781865254/product/d1ab0a1eec8118ac7790af7284392e3d.webp",
    "isEnabled": true
  },
  {
    "id": 73,
    "code": "-",
    "name": "Fingers piquant 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781865959/product/8f66876957148e10f9e61d9b23347171.webp",
    "isEnabled": true
  },
  {
    "id": 74,
    "code": "-",
    "name": "Haut cuisse de dinde avec os 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1757417618/product/27b2cb2e9ddce1f0f5e529c15ea0ee86.webp",
    "isEnabled": true
  },
  {
    "id": 75,
    "code": "5024",
    "name": "Haut cuisse de poulet avec os 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2625897002000",
    "isEnabled": true
  },
  {
    "id": 76,
    "code": "5024",
    "name": "Haut de cuisse de poulet 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2625897002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743699054/product/5c29a0bae55c8f0c45f6a528d43f687f.webp",
    "isEnabled": true
  },
  {
    "id": 77,
    "code": "-",
    "name": "Lapin entier 1,2Kg",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751457966/product/25b919558df747270d37ff9c029e2bec.webp",
    "isEnabled": true
  },
  {
    "id": 78,
    "code": "-",
    "name": "Magret de canard environ 400g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1767091002/product/37c931fae3098aa8307e49a800db1209.webp",
    "isEnabled": true
  },
  {
    "id": 79,
    "code": "1258",
    "name": "Nuggets de poulet environ 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2639647002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1732300328/product/2cf0d4c39e10d78cdf87db565f9a274f.webp",
    "isEnabled": true
  },
  {
    "id": 80,
    "code": "1353",
    "name": "Osso bucco de dinde 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610106001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587296691/product_optimized/68fa01ecdf095ad3e8b8d2918959e9b0.webp",
    "isEnabled": true
  },
  {
    "id": 81,
    "code": "7850",
    "name": "Pigeon 2 unités",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2676432000017",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751458281/product/48c266b867db63895cb4dbff3f32c654.webp",
    "isEnabled": true
  },
  {
    "id": 82,
    "code": "1344",
    "name": "Pilon de dinde 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610099005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781866270/product/657a1542373e918239a791dbaa833112.webp",
    "isEnabled": true
  },
  {
    "id": 83,
    "code": "3018",
    "name": "Pilon de poulet environ 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2600979002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1759915801/product/27354837698a86a600e07c493dc34abc.webp",
    "isEnabled": true
  },
  {
    "id": 84,
    "code": "7669",
    "name": "Pilons de poulet mariné 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2635952002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588272225/product_optimized/677e5822d746e355ca9729f3c0318f5c.webp",
    "isEnabled": true
  },
  {
    "id": 85,
    "code": "-",
    "name": "Poulet Bio environ 1Kg",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751458494/product/ff2279536a18eeebf36b135a205cbe10.webp",
    "isEnabled": true
  },
  {
    "id": 86,
    "code": "1429",
    "name": "Poulet entier (environ 1,25Kg)",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610168012500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1591215388/product_optimized/f7c611c0c134e3c02b7dd6d417cb5c9e.webp",
    "isEnabled": true
  },
  {
    "id": 87,
    "code": "9365",
    "name": "Poulet fermier coco gibier environ 1,3Kg",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2654190013000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781868709/product/0da5cc3ae5c974e079041746ddfef1f0.webp",
    "isEnabled": true
  },
  {
    "id": 88,
    "code": "8799",
    "name": "Poulet Fermier Eldin au Kg",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2653905013000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1784816459/product/760179663e0b252a4dddba0c26c231d0.webp",
    "isEnabled": true
  },
  {
    "id": 89,
    "code": "5341",
    "name": "Poulet fermier premium (1,3Kg)",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2635968013000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1644262357/product_optimized/77fa86b5b116fc8565df87dbfe8effd4.webp",
    "isEnabled": true
  },
  {
    "id": 90,
    "code": "1897",
    "name": "Poulet x1 environ 1,25Kg - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2698128012500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1749219824/product/66b284f22d763a8112a81a93b7b7f158.webp",
    "isEnabled": true
  },
  {
    "id": 91,
    "code": "1895",
    "name": "Poulet x2 environ 1,25Kg - FILIERE M",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2698236025000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1748602105/product/82a7d42833566a59cc8e6671975185e7.webp",
    "isEnabled": true
  },
  {
    "id": 92,
    "code": "9861",
    "name": "Saucisse à la marocaine 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2630528002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1748528434/product/095b3d3a2cec46cf9db3b411a5cee3bc.webp",
    "isEnabled": true
  },
  {
    "id": 93,
    "code": "6474",
    "name": "Saucisse poulet fines herbes 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2666614002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642490264/product_optimized/65764ed127968eba68c1b3e0b5ec9f45.webp",
    "isEnabled": true
  },
  {
    "id": 94,
    "code": "4844",
    "name": "Saucisse poulet origan 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2637594002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587320718/product_optimized/939a04ef3101caf1681c0cf437f3d4c3.webp",
    "isEnabled": true
  },
  {
    "id": 95,
    "code": "5345",
    "name": "Saucisse poulet piquant environ 250g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2666612002500",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744298717/product/0645da7381ed8feb55f84c438126a7a1.webp",
    "isEnabled": true
  },
  {
    "id": 96,
    "code": "9823",
    "name": "Saucisse volaille fromage 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2630208002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642457408/product_optimized/5772722499e1d8f7715d3e48a79a88ae.webp",
    "isEnabled": true
  },
  {
    "id": 97,
    "code": "4320",
    "name": "Saucisse volaille nature 200g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2666611002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1642457502/product_optimized/05cf2c525432ee302ab2d4fa09b6b3d1.webp",
    "isEnabled": true
  },
  {
    "id": 98,
    "code": "1368",
    "name": "Viande hachée de dinde épicée 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610120005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1743695628/product/ed95e79aba2814c614b3c4c11282ea44.webp",
    "isEnabled": true
  },
  {
    "id": 99,
    "code": "1369",
    "name": "Viande hachée de dinde nature 500g",
    "department": "Boucherie et volaille",
    "category": "Volaille",
    "barcodeMjValide": "2610121005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587298149/product_optimized/e600965db805d75828f04e0575715e00.webp",
    "isEnabled": true
  },
  {
    "id": 100,
    "code": "8490",
    "name": "Fromage Abondance Laitière 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698712001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162857/product/83b3b0aeb8556acadcbe2bfcb513b895.webp",
    "isEnabled": true
  },
  {
    "id": 101,
    "code": "8495",
    "name": "Fromage Appenzel Surchoix 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698708001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165564/product/de68a85964cde4dbff60b60bf6e3c71c.webp",
    "isEnabled": true
  },
  {
    "id": 102,
    "code": "8499",
    "name": "Fromage appenzeller classic 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2676421001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155414/product/d095f950f30f3cf83d524d21c4c6ea65.webp",
    "isEnabled": true
  },
  {
    "id": 103,
    "code": "-",
    "name": "Fromage Black Garlic Bloc 100g - JACK CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776164562/product/1042ec9ccef4d797addaea38c27c590a.webp",
    "isEnabled": true
  },
  {
    "id": 104,
    "code": "-",
    "name": "Fromage black garlic en morceau 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1768988165/product/c7b5134dcf2fbce0797c162c71409acf.webp",
    "isEnabled": true
  },
  {
    "id": 105,
    "code": "-",
    "name": "Fromage Black Lemon en bloc 100g - JACK CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156363/product/5ee0e03f862cfd35fee62c5841e10e65.webp",
    "isEnabled": true
  },
  {
    "id": 106,
    "code": "738",
    "name": "Fromage Bleu Auvergne Russel 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639760001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776858732/product/cf044440860fb43d5e311a00f95b7607.webp",
    "isEnabled": true
  },
  {
    "id": 107,
    "code": "8527",
    "name": "Fromage Bleu Brebis 'Memée' Demi 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2654765001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165840/product/5734f4f195debeec4a3d4587606ae3df.webp",
    "isEnabled": true
  },
  {
    "id": 108,
    "code": "3475",
    "name": "Fromage Bleu d'Auvergne AOP Entier Dischamp 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2634280001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162312/product/e1a9f4e353e897bcbc2295d6d39c77b4.webp",
    "isEnabled": true
  },
  {
    "id": 109,
    "code": "8543",
    "name": "Fromage Bleu des Causses 'Memée' 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2654665001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165916/product/302cd1bba194078257bdd4e2cba34a96.webp",
    "isEnabled": true
  },
  {
    "id": 110,
    "code": "1184",
    "name": "Fromage Bleu en morceau 100g - BERGARDER",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2624487001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744728912/product/e779cd0bfbe25eb6af50c9a7632654c5.webp",
    "isEnabled": true
  },
  {
    "id": 111,
    "code": "1411",
    "name": "Fromage Bresse Bleu 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639402001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776858047/product/47ef6e0af211546694ac63f76b6a646c.webp",
    "isEnabled": true
  },
  {
    "id": 112,
    "code": "2438",
    "name": "Fromage Brie à la Truffe Spanish 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2650159001000",
    "barcodeSecours": "2000014827356",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776160313/product/50eb0f96ea89fb7b17f061a190aa0a77.webp",
    "isEnabled": true
  },
  {
    "id": 113,
    "code": "9112",
    "name": "Fromage brie crémeux 100g - ILE DE FRANCE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639985001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761663450/product/e0d17f53a6cd6cdc2baefe1270515015.webp",
    "isEnabled": true
  },
  {
    "id": 114,
    "code": "726",
    "name": "Fromage brie Cœur de Lion 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639663001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776158795/product/6780ee280cd8c21c191f0115197655e5.webp",
    "isEnabled": true
  },
  {
    "id": 115,
    "code": "71",
    "name": "Fromage Brie en morceau 100g - PRÉSIDENT",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639104001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756223578/product/5e62ae090d962b5f91fdc3095b03712a.webp",
    "isEnabled": true
  },
  {
    "id": 116,
    "code": "8578",
    "name": "Fromage Cantal AOP Entre Deux 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2654032001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776161308/product/c9a86066944d6abdd85e60293494eace.webp",
    "isEnabled": true
  },
  {
    "id": 117,
    "code": "9873",
    "name": "Fromage cheddar en bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2609811001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761750049/product/a6143e0b88f494ad0b3c9f0ce8b2e5ea.webp",
    "isEnabled": true
  },
  {
    "id": 118,
    "code": "6951",
    "name": "Fromage cheddar en bloc 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2602489001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159871/product/44e03290e2e145191bf6d08d6b1fbef6.webp",
    "isEnabled": true
  },
  {
    "id": 119,
    "code": "-",
    "name": "Fromage cheesarella 100g - KHAYRAT",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1769079676/product/8d4012f525739fcc59c2e7b0c4e3780f.webp",
    "isEnabled": true
  },
  {
    "id": 120,
    "code": "2768",
    "name": "Fromage Chèvre 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2631438001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165356/product/37e99abf6a4a0e1567325fd5facedf68.webp",
    "isEnabled": true
  },
  {
    "id": 121,
    "code": "-",
    "name": "Fromage chèvre herbes italiens 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1739446443/product/7801e95b6ad8b829026911e5d5aaec15.webp",
    "isEnabled": true
  },
  {
    "id": 122,
    "code": "-",
    "name": "Fromage Comté 100g - PRESIDENT",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781795941/product/bcdc5c9c1693167d75198bc713545e0c.webp",
    "isEnabled": true
  },
  {
    "id": 123,
    "code": "8582",
    "name": "Fromage Comté AOP +18M Rivoire 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2634198001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162453/product/f265567c716b409df0cf9c9f335de72d.webp",
    "isEnabled": true
  },
  {
    "id": 124,
    "code": "8579",
    "name": "Fromage Comté Bio 5.6M Arnaud 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698124001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776160066/product/d2a5263e2f18e392bc031dca62dcbf72.webp",
    "isEnabled": true
  },
  {
    "id": 125,
    "code": "4918",
    "name": "Fromage de brebis à la tomate et origan 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2640037001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781797755/product/4c3319bd8b14f79a93c64ebf1e1336f5.webp",
    "isEnabled": true
  },
  {
    "id": 126,
    "code": "4920",
    "name": "Fromage de brebis affiné à l'ail noir 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2654011001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781798026/product/21db61a1fb2292c0d77ab255b184a86f.webp",
    "isEnabled": true
  },
  {
    "id": 127,
    "code": "5219",
    "name": "Fromage de brebis affiné au romarin 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2651879001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155261/product/f1241df31466ee67ac6020ef36e86aa9.webp",
    "isEnabled": true
  },
  {
    "id": 128,
    "code": "4917",
    "name": "Fromage de brebis affiné aux fleurs 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2625436001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776154645/product/d26d00de33aab7199d87f2c715cd4d04.webp",
    "isEnabled": true
  },
  {
    "id": 129,
    "code": "-",
    "name": "Fromage de brebis affiné saveur truffe layenda 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2623453001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781797343/product/d3539344ac91a2574b85852c18385821.webp",
    "isEnabled": true
  },
  {
    "id": 130,
    "code": "4916",
    "name": "Fromage de Brebis aux olives noires 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2654018001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776160458/product/06461413c52555bfcda5d0e2dec9eb6e.webp",
    "isEnabled": true
  },
  {
    "id": 131,
    "code": "4919",
    "name": "Fromage de brebis aux pesto de la toscana 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781797555/product/6684809636db0c027e1819cbef9270d7.webp",
    "isEnabled": true
  },
  {
    "id": 132,
    "code": "4921",
    "name": "Fromage de brebis mi-affiné au safran Layenda 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2651984001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776158675/product/d225fecd0be9e9672dcf7edc35fdb271.webp",
    "isEnabled": true
  },
  {
    "id": 133,
    "code": "4923",
    "name": "Fromage de brebis nature 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2671398001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155704/product/8c3b7a02d7ca6acbc6ed43f09bf06298.webp",
    "isEnabled": true
  },
  {
    "id": 134,
    "code": "-",
    "name": "Fromage de brebis tendre chili piquant 100g - LAYENDA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2651098001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1788789685/product/6b2e97ea23a52065a25ac29c6f043d90.webp",
    "isEnabled": true
  },
  {
    "id": 135,
    "code": "-",
    "name": "Fromage de chèvre doux bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1739444670/product/0784bf4292aaabb972eab32abd7b4b30.webp",
    "isEnabled": true
  },
  {
    "id": 136,
    "code": "6342",
    "name": "Fromage de chèvre en bûche 100g - LA P'TITE CHEVRE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2687461001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1754388429/product/0f3f91076beca64791f91c31031ea587.webp",
    "isEnabled": true
  },
  {
    "id": 137,
    "code": "9345",
    "name": "Fromage Edam 45% m.g. en morceau 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2637151001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1614671490/product_optimized/f7d3b540ac62567e70e8641187ffb869.webp",
    "isEnabled": true
  },
  {
    "id": 138,
    "code": "6952",
    "name": "Fromage edam blanc 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2695361001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776160755/product/07e60f9c9a4ad0459f2c50193aab70d4.webp",
    "isEnabled": true
  },
  {
    "id": 139,
    "code": "-",
    "name": "Fromage Edam Boule 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2678549001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1788789861/product/3e2e587165157a271b4ecd134315cf28.webp",
    "isEnabled": true
  },
  {
    "id": 140,
    "code": "3476",
    "name": "Fromage Edam en boule 100g - PRESIDENT",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698123001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159982/product/85f088166012ab519f04a44945aac46a.webp",
    "isEnabled": true
  },
  {
    "id": 141,
    "code": "2954",
    "name": "Fromage Edam en morceau 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2685321001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1614671875/product_optimized/07cd831fd526029253eb106305a423b9.webp",
    "isEnabled": true
  },
  {
    "id": 142,
    "code": "5674",
    "name": "Fromage Edam en morceau 100g - KROON",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2678549001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1684832182/product_optimized/85d392bf6516ab869a174e0f8baa8daa.webp",
    "isEnabled": true
  },
  {
    "id": 143,
    "code": "6464",
    "name": "Fromage Edam en morceau 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2651484001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1749113723/product/5f330c39fca4afd1bffb50949b2905a9.webp",
    "isEnabled": true
  },
  {
    "id": 144,
    "code": "2760",
    "name": "Fromage edam en portion 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2697482001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776154771/product/82c18549ba48c9d89cde6bd2ee7f1ffa.webp",
    "isEnabled": true
  },
  {
    "id": 145,
    "code": "155",
    "name": "Fromage emmental Bloc 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2624132001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159457/product/c786685bb580789fe33f8df086a12df8.webp",
    "isEnabled": true
  },
  {
    "id": 146,
    "code": "2615",
    "name": "Fromage Emmental en morceau 100g - PRÉSIDENT",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639514001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756224134/product/2553130e557451b1510c3cc3ea2beab6.webp",
    "isEnabled": true
  },
  {
    "id": 147,
    "code": "-",
    "name": "Fromage Etorki Coupé 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162243/product/ac9bfdd3ed3e6c1b09581a7dba865e0b.webp",
    "isEnabled": true
  },
  {
    "id": 148,
    "code": "311",
    "name": "Fromage Folepi 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639044001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159046/product/c4c9f4c10212b1aa452a03f88c2bf0dc.webp",
    "isEnabled": true
  },
  {
    "id": 149,
    "code": "8585",
    "name": "Fromage Fourme d'Ambert AOP Dischamp 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2632489001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776160922/product/7435ceb032487756a043d5424fe4fc9f.webp",
    "isEnabled": true
  },
  {
    "id": 150,
    "code": "8946",
    "name": "Fromage fumé au poivre en tranche 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2693930001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1753973817/product/3e386b499e7ae41ec218b938121be8c3.webp",
    "isEnabled": true
  },
  {
    "id": 151,
    "code": "7926",
    "name": "Fromage fumé aux herbes 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2600214001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781793939/product/36a0ed3bfcfff96110d47abeb78072b2.webp",
    "isEnabled": true
  },
  {
    "id": 152,
    "code": "7926",
    "name": "Fromage fumé aux herbes en tranche 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2600214001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1753974178/product/f4044e8d107900a9c7fd34a22a16521d.webp",
    "isEnabled": true
  },
  {
    "id": 153,
    "code": "2587",
    "name": "Fromage fumé en bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2609878001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761749326/product/c4c40c945e0298fa6709ba0499b7da72.webp",
    "isEnabled": true
  },
  {
    "id": 154,
    "code": "7927",
    "name": "Fromage Fumé nature en tranche 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2636540001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1753973354/product/a5ea49d515776126bfec3037bef849e2.webp",
    "isEnabled": true
  },
  {
    "id": 155,
    "code": "7925",
    "name": "Fromage fumé piquant chili 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2675106001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781251780/product/d9c4c414edf208ff0fb95820db5ecf83.webp",
    "isEnabled": true
  },
  {
    "id": 156,
    "code": "7925",
    "name": "Fromage fumé piquant chili en tranche 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2675106001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1753974300/product/cf1eb6dbe6ce1fc55b95fac9b029ee61.webp",
    "isEnabled": true
  },
  {
    "id": 157,
    "code": "8946",
    "name": "Fromage fumé poivre 200g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2693930001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776263886/product/051b7edffb7956d9f68d5274a8f6336b.webp",
    "isEnabled": true
  },
  {
    "id": 158,
    "code": "-",
    "name": "Fromage fumé red chili bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1739523520/product/8963cf56bf8aa36cc502bc84183898cb.webp",
    "isEnabled": true
  },
  {
    "id": 159,
    "code": "2761",
    "name": "Fromage Gold pur en portion 100g - HENRI WILLIG",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2634189001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155865/product/e7fbc7c31974020ec4f677f2aacb0e93.webp",
    "isEnabled": true
  },
  {
    "id": 160,
    "code": "7609",
    "name": "Fromage Gorgonzola Zanetti 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639041001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776163145/product/ce1dff485dc504f726d4c3446854c582.webp",
    "isEnabled": true
  },
  {
    "id": 161,
    "code": "2956",
    "name": "Fromage Gouda au cumin en morceau 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2635915001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756221060/product/a0ae19ef46dc77453583a5e3cd5054eb.webp",
    "isEnabled": true
  },
  {
    "id": 162,
    "code": "-",
    "name": "Fromage gouda aux herbes italiens bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1739441354/product/fee27a102e1f67203347b3bf67f3d1c3.webp",
    "isEnabled": true
  },
  {
    "id": 163,
    "code": "-",
    "name": "Fromage gouda aux truffes noirs bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1746458924/product/c73e054266c9a3da5ebdbaeb13d2d0f8.webp",
    "isEnabled": true
  },
  {
    "id": 164,
    "code": "9754",
    "name": "Fromage gouda bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2635928001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738359228/product/05dd196158333bfdec4dc56278ef142e.webp",
    "isEnabled": true
  },
  {
    "id": 165,
    "code": "8664",
    "name": "Fromage gouda chili bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639785001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761734968/product/c07d0213f33928a7769f6b49f93a3358.webp",
    "isEnabled": true
  },
  {
    "id": 166,
    "code": "8460",
    "name": "Fromage Gouda Chili Piquant Meule 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2635254001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165234/product/2acc907062165d7056e43af844193782.webp",
    "isEnabled": true
  },
  {
    "id": 167,
    "code": "2763",
    "name": "Fromage gouda cumin 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2697454001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776161907/product/36576d96efbe577dbc5c7af30be1528d.webp",
    "isEnabled": true
  },
  {
    "id": 168,
    "code": "-",
    "name": "Fromage gouda cumin bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738358437/product/13514cfa42d674bbe23573f298c8e958.webp",
    "isEnabled": true
  },
  {
    "id": 169,
    "code": "9290",
    "name": "Fromage gouda cumin en bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2605002001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761752266/product/1efea1831e77da81665f5b437d7816ce.webp",
    "isEnabled": true
  },
  {
    "id": 170,
    "code": "7048",
    "name": "Fromage Gouda cumin en morceau 100g - KROON",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2676854001000",
    "barcodeSecours": "2000014424074",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1684832616/product_optimized/f96ede09165af9fa1f3ad57fddf0daf6.webp",
    "isEnabled": true
  },
  {
    "id": 171,
    "code": "8592",
    "name": "Fromage gouda de chèvre Mekkerstee Bio 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2654398001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776857199/product/2adf6c148bd13948a17c670c39564de7.webp",
    "isEnabled": true
  },
  {
    "id": 172,
    "code": "-",
    "name": "Fromage gouda jalapeno bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1739438720/product/3802a7c18b694d8ab08bc5b639bef38c.webp",
    "isEnabled": true
  },
  {
    "id": 173,
    "code": "8461",
    "name": "Fromage gouda light en meule 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2635147001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155588/product/571fb83def86a7a21fff616c04cda8be.webp",
    "isEnabled": true
  },
  {
    "id": 174,
    "code": "2766",
    "name": "Fromage gouda moutarde 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2631425001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159650/product/93df5d69783038e286b081be4b407b30.webp",
    "isEnabled": true
  },
  {
    "id": 175,
    "code": "9704",
    "name": "Fromage Gouda moutarde en bloc 100g - JACK CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2639556001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1739440870/product/2a7589eabb49ddba36d2fd82c058e784.webp",
    "isEnabled": true
  },
  {
    "id": 176,
    "code": "9748",
    "name": "Fromage gouda nature 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2605254001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738355544/product/f321dcef25de7d191710e3aab84fc68c.webp",
    "isEnabled": true
  },
  {
    "id": 177,
    "code": "9748",
    "name": "Fromage gouda nature bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2605254001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738356380/product/609d1b55325f5875e3391a3af76ce77e.webp",
    "isEnabled": true
  },
  {
    "id": 178,
    "code": "1288",
    "name": "Fromage gouda nature bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2608420001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761751065/product/a95f428b892f1d6b4b244146e964a667.webp",
    "isEnabled": true
  },
  {
    "id": 179,
    "code": "6950",
    "name": "Fromage gouda nature en bloc 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639517001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162012/product/f465785d429444a3690752171ee26ec1.webp",
    "isEnabled": true
  },
  {
    "id": 180,
    "code": "2955",
    "name": "Fromage Gouda nature en morceau 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2691481001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744728686/product/f80bbcd9fa7c04049deae3194dfb4460.webp",
    "isEnabled": true
  },
  {
    "id": 181,
    "code": "7047",
    "name": "Fromage Gouda nature en morceau 100g - KROON",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2687564001000",
    "barcodeSecours": "2000014424104",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1684832396/product_optimized/2819d666dee40df60fdc347c35507247.webp",
    "isEnabled": true
  },
  {
    "id": 182,
    "code": "2762",
    "name": "Fromage Gouda nature en portion 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639741001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156145/product/58814a568f2c37be039cf620cd66a59d.webp",
    "isEnabled": true
  },
  {
    "id": 183,
    "code": "8668",
    "name": "Fromage gouda pesto en bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639842001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761747744/product/f0532f8c96d5d05e56054234d8371f5f.webp",
    "isEnabled": true
  },
  {
    "id": 184,
    "code": "2767",
    "name": "Fromage Gouda pesto vert en portion 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2630041001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156213/product/e91b5d76c208d62f2d5ab813e3d6edc8.webp",
    "isEnabled": true
  },
  {
    "id": 185,
    "code": "2765",
    "name": "Fromage Gouda poivre en portion 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2631004001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156048/product/9e55d224a8224425e278163192a10833.webp",
    "isEnabled": true
  },
  {
    "id": 186,
    "code": "9707",
    "name": "Fromage gouda wasabi bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698416001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738353386/product/812d4021dcb2ac7dca2e4838af8fda50.webp",
    "isEnabled": true
  },
  {
    "id": 187,
    "code": "7610",
    "name": "Fromage grana Padano Zanetti 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639579001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159545/product/4676cdee57f9a96b76646a350e06e606.webp",
    "isEnabled": true
  },
  {
    "id": 188,
    "code": "8593",
    "name": "Fromage gruyère suisse 100g - EMI",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2657641001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155028/product/cb151c650a83aeaac290b239d6688d02.webp",
    "isEnabled": true
  },
  {
    "id": 189,
    "code": "6485",
    "name": "Fromage Iberico Curado 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2631484001000",
    "imageUrl": "https://maisonriopedre.com/wp-content/uploads/2019/04/Fromage-de-brebis-curado.png",
    "isEnabled": true
  },
  {
    "id": 190,
    "code": "1574",
    "name": "Fromage lait cru IGP entier 100g - TOMME DE SAVOIE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2665126001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776855926/product/839e3e4810e3e3093598366350059250.webp",
    "isEnabled": true
  },
  {
    "id": 191,
    "code": "9761",
    "name": "Fromage maasdam bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2630115001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738345406/product/3495644d7d460a89ba2f5c0593b59465.webp",
    "isEnabled": true
  },
  {
    "id": 192,
    "code": "9291",
    "name": "Fromage maasdam en bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2602366001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761753037/product/b58dc0063adaacbfd1f1c8b55b0fc3d9.webp",
    "isEnabled": true
  },
  {
    "id": 193,
    "code": "6949",
    "name": "Fromage Maasdam en bloc 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698741001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776161836/product/1982e084415b11c4856764cb84ae77b8.webp",
    "isEnabled": true
  },
  {
    "id": 194,
    "code": "8462",
    "name": "Fromage maasdam en meule 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2651487001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155516/product/a8c8732a71b2ad5b78016d76f0a1c39d.webp",
    "isEnabled": true
  },
  {
    "id": 195,
    "code": "2957",
    "name": "Fromage Maasdam en morceau 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2615248001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1614673104/product_optimized/35bc21f8b1adc1e52b6dc9744a0ba91a.webp",
    "isEnabled": true
  },
  {
    "id": 196,
    "code": "2937",
    "name": "Fromage Maasdam en morceau 100g - KROON",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2634521001000",
    "barcodeSecours": "2000014424043",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1684832661/product_optimized/2a4bcc7c0c6e63b8cbd2609f9018750c.webp",
    "isEnabled": true
  },
  {
    "id": 197,
    "code": "3380",
    "name": "Fromage Manchego en portion 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639970001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156980/product/c64bfbd7d4dd15d4a788df21e3dffb8b.webp",
    "isEnabled": true
  },
  {
    "id": 198,
    "code": "1574",
    "name": "Fromage manchego Mancha Dorada 12M 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2665126001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776158391/product/742f500c049502358b21df1ebebfd307.webp",
    "isEnabled": true
  },
  {
    "id": 199,
    "code": "8080",
    "name": "Fromage mimolette en bloc 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2656541001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162095/product/4f22bff7f59eed2b67bd2b330de7e0ee.webp",
    "isEnabled": true
  },
  {
    "id": 200,
    "code": "1566",
    "name": "Fromage Morbier Le Montagnon AOP Lait Cru 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2665132001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776859393/product/5ca069b1f8a3123866a878d7cd95532e.webp",
    "isEnabled": true
  },
  {
    "id": 201,
    "code": "3420",
    "name": "Fromage mozzarella en bloc 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698730001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761812141/product/3d65e4472ffe914fc8cacdfc2aea5cda.webp",
    "isEnabled": true
  },
  {
    "id": 202,
    "code": "2336",
    "name": "Fromage Mozzarella en morceau 100g - OR BLANC",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639158001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756217331/product/111fa55325984a2edd2593c30d8c2e43.webp",
    "isEnabled": true
  },
  {
    "id": 203,
    "code": "-",
    "name": "Fromage mozzarella en trances 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMarjane": "2696730001000",
    "imageUrl": "https://glovo.dhmedia.io/image/pim-glovo/695e49f8b4ea467f81cee4a4.webp?t=W3sicmVzaXplIjp7Im1vZGUiOiJmaXQiLCJ3aWR0aCI6MzIwLCJoZWlnaHQiOjMyMH19XQ==",
    "isEnabled": true
  },
  {
    "id": 204,
    "code": "8636",
    "name": "Fromage munster épais AOP 100g - HAXAIRE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2643096001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776856159/product/eaf98280c259d0b302b143846869a7cd.webp",
    "isEnabled": true
  },
  {
    "id": 205,
    "code": "-",
    "name": "Fromage nature gouda 100g - GRAND CŒUR",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781251486/product/7aed006dbd25a10e9c5a57779d5eb693.webp",
    "isEnabled": true
  },
  {
    "id": 206,
    "code": "1565",
    "name": "Fromage Ossau Iraty Capitoul - 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2665131001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776859197/product/25f1d10f8154730fe96a4e168726cc19.webp",
    "isEnabled": true
  },
  {
    "id": 207,
    "code": "1764",
    "name": "Fromage Parmesan en morceau 100g - TOSCANELLO",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2641241001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1614675115/product_optimized/c6fd1284430fbe1d4aa6bf35d50cf56b.webp",
    "isEnabled": true
  },
  {
    "id": 208,
    "code": "8402",
    "name": "Fromage parmigiano reggiano 15 mois AOP 100g - BONI",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2671254001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776154954/product/1130b9ffbfe2709447c3e3aaa3cbad54.webp",
    "isEnabled": true
  },
  {
    "id": 209,
    "code": "2792",
    "name": "Fromage pecorino à la Truffe 100g - ZANETTI",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2695147001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776857648/product/c5d3949e5c7a51b0700cd7e15b303a79.webp",
    "isEnabled": true
  },
  {
    "id": 210,
    "code": "4548",
    "name": "Fromage perenero en bloc 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2666676001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155794/product/6125d1b22af87d1b8ed304f8fa5a37e2.webp",
    "isEnabled": true
  },
  {
    "id": 211,
    "code": "8403",
    "name": "Fromage Pont-l'Évêque Graindorge 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2634219001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776164385/product/56d081907f4e496a66ff8aeec000578d.webp",
    "isEnabled": true
  },
  {
    "id": 212,
    "code": "3383",
    "name": "Fromage Pyrenero Meule 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2695408001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776159329/product/7c3a4add8cec2b2b5cc3aa63932fd32f.webp",
    "isEnabled": true
  },
  {
    "id": 213,
    "code": "3460",
    "name": "Fromage raclette 100g - CAMPAGNE DE FRANCE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2698213001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1766152921/product/f5bb2c39ecd8777ca4c7c121eac41a79.webp",
    "isEnabled": true
  },
  {
    "id": 214,
    "code": "1570",
    "name": "Fromage Raclette à la Truffe Lait Cru Bouchet 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2665130001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165010/product/fde185808cad5c97b9555e7d69eaa791.webp",
    "isEnabled": true
  },
  {
    "id": 215,
    "code": "8404",
    "name": "Fromage raclette de savoie IGP tournetté 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2657578001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776155321/product/3052a3afd4c5ba057035d5a61f66b047.webp",
    "isEnabled": true
  },
  {
    "id": 216,
    "code": "9117",
    "name": "Fromage Raclettes Le Rustique 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639870001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165769/product/9e0a9661117df6dcf28642ffce006e93.webp",
    "isEnabled": true
  },
  {
    "id": 217,
    "code": "9668",
    "name": "Fromage rambol aux noix 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639762001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776158940/product/9d5597f55b1fec555da04ad0fc6f951c.webp",
    "isEnabled": true
  },
  {
    "id": 218,
    "code": "333",
    "name": "Fromage Rambol crémeux FH en portion 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639015001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156581/product/8304b4f54e11d6aff4d07b460c53b655.webp",
    "isEnabled": true
  },
  {
    "id": 219,
    "code": "3620",
    "name": "Fromage Rambol Crémeux Saumon 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639848001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162172/product/528d87eed78af1b9d120aedacaa8582b.webp",
    "isEnabled": true
  },
  {
    "id": 220,
    "code": "3070",
    "name": "Fromage Ricotta 0% en morceau 100g - FROMADEL",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2668954001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744727455/product/8a68aa7861ef8ccee4e6998763ac9420.webp",
    "isEnabled": true
  },
  {
    "id": 221,
    "code": "1018",
    "name": "Fromage rondin blanc Cryovac 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639155001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776157266/product/4f8bd8c2f55ab76223fe50637ad16fd1.webp",
    "isEnabled": true
  },
  {
    "id": 222,
    "code": "1017",
    "name": "Fromage Rondin Cryovac Cendré 50% 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639154001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1777024905/product/baeae0bffcfd7dca03a19cdecd81b9fd.webp",
    "isEnabled": true
  },
  {
    "id": 223,
    "code": "-",
    "name": "Fromage Rondin Herbes Cryovac (9514) 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1788789516/product/d8664aa0be8cab45100f71971439cf05.webp",
    "isEnabled": true
  },
  {
    "id": 224,
    "code": "3388",
    "name": "Fromage roquefort Société 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639961001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776856701/product/cc1307881717e6960a550e3521b4714c.webp",
    "isEnabled": true
  },
  {
    "id": 225,
    "code": "-",
    "name": "Fromage rose leaves en bloc 100g - JACK CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156455/product/4460d9e2fc3f48ecab81d9d64ab72f03.webp",
    "isEnabled": true
  },
  {
    "id": 226,
    "code": "-",
    "name": "Fromage rose leaves en morceau 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1768989667/product/27e5293bdfb2d60e404c15a0b933a12f.webp",
    "isEnabled": true
  },
  {
    "id": 227,
    "code": "-",
    "name": "Fromage Saint Albray coupe en portion 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776156716/product/9d9b6dcde1e70c754955f16c283743e4.webp",
    "isEnabled": true
  },
  {
    "id": 228,
    "code": "8430",
    "name": "Fromage Saint Nectaire Laitier Long Life Dischamp 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2677768001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776162530/product/09554d0fb2d178d4103db7c121512c36.webp",
    "isEnabled": true
  },
  {
    "id": 229,
    "code": "8414",
    "name": "Fromage Saint Paulin 23%mg 100g - CAMPAGNE DE France",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2677760001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776161706/product/a0e001c5f667215d3a19d5f24db8ff99.webp",
    "isEnabled": true
  },
  {
    "id": 230,
    "code": "-",
    "name": "Fromage Tabasco Peppers Bloc 100g - JACK CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776164690/product/c598580515d209a5a59c1c8ebf736eda.webp",
    "isEnabled": true
  },
  {
    "id": 231,
    "code": "-",
    "name": "Fromage tabasco peppers en morceau 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1768989944/product/452b7d6d412ef2963499f8d1f07802a9.webp",
    "isEnabled": true
  },
  {
    "id": 232,
    "code": "-",
    "name": "Fromage tête de Moine Gold 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776856992/product/35f2083afb4e207713795c8f762d5a41.webp",
    "isEnabled": true
  },
  {
    "id": 233,
    "code": "-",
    "name": "Fromage Texas Barbecue Bloc 100g - JACK CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165643/product/f92db71cb3c8b1314ac3b0cdabaf1a03.webp",
    "isEnabled": true
  },
  {
    "id": 234,
    "code": "-",
    "name": "Fromage Texas barbecue en morceau 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1768991403/product/ef01eb0f397d806187f34a3ce9ccda9d.webp",
    "isEnabled": true
  },
  {
    "id": 235,
    "code": "8416",
    "name": "Fromage tomme brebis Pecorinu 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2677762001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776158246/product/bb75655d42be2a09949b28060b7f2788.webp",
    "isEnabled": true
  },
  {
    "id": 236,
    "code": "8890",
    "name": "Fromage Tomme noire des Pyrénées en morceau 100g - BONGRAIN SAVECIA",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639027001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1744730575/product/718525f609aa646c4f45ee3520270050.webp",
    "isEnabled": true
  },
  {
    "id": 237,
    "code": "8407",
    "name": "Fromage Tomme pur chèvre en portion 100g - ONETIK",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2675649001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776163786/product/3299b8e5a252d14ee0848d314fb1bb34.webp",
    "isEnabled": true
  },
  {
    "id": 238,
    "code": "-",
    "name": "Fromage tricolore bloc 100g - JACKS CHEESE",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738354751/product/06c3b6b0353faab3fde8515419dbbef5.webp",
    "isEnabled": true
  },
  {
    "id": 239,
    "code": "1575",
    "name": "Fromage Vacherin Fribourgeois AOP Rustic Frisé 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2665125001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776859617/product/a551a62d2d0f7cd79ee597960722b09c.webp",
    "isEnabled": true
  },
  {
    "id": 240,
    "code": "296",
    "name": "Fromage Vieux Pane Coupé 100g",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2639076001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776857883/product/4f8f505b3cc36f5c3ca9276a0c75abdd.webp",
    "isEnabled": true
  },
  {
    "id": 241,
    "code": "8555",
    "name": "Tarte de brie en bloc 100g - PAYSAN BRETON",
    "department": "Fromage et charcuterie",
    "category": "Fromages",
    "barcodeMjValide": "2621587001000",
    "imageUrl": "https://storage.googleapis.com/sales-img-ma-live/web/cache/sylius_large/28/23/9ba613f8c809cde840b6d946f17d.jpg",
    "isEnabled": true
  },
  {
    "id": 242,
    "code": "-",
    "name": "Blanc de dinde light 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771858381/product/d9ed6bf7fa1aacf6785a522ebf04080a.webp",
    "isEnabled": true
  },
  {
    "id": 243,
    "code": "-",
    "name": "Cornet de Poulet 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771845727/product/0ecacf2f948308d212074d737abc0b4c.webp",
    "isEnabled": true
  },
  {
    "id": 244,
    "code": "-",
    "name": "Cuisse de dinde 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771844267/product/fa491086f12dc61fb5059adde7b99ce1.webp",
    "isEnabled": true
  },
  {
    "id": 245,
    "code": "6173",
    "name": "Cuisse de dinde au poivre noir en tranches 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2623455001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783672278/product/d77f133ab36807f98a900171a3d0e41e.webp",
    "isEnabled": true
  },
  {
    "id": 246,
    "code": "7125",
    "name": "Cuisse de dinde fumé au poivre 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2623453001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773220207/product/547ea7cb7334ade8db2ba1c7f79765d1.webp",
    "isEnabled": true
  },
  {
    "id": 247,
    "code": "-",
    "name": "Cuisse de Dinde Mavi 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776165996/product/bd2e15e37ec97615c78b2832ac29f28f.webp",
    "isEnabled": true
  },
  {
    "id": 248,
    "code": "-",
    "name": "Duo bœuf / poulet 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771845801/product/a74fba3f87f63a0510f5ac5714c6b764.webp",
    "isEnabled": true
  },
  {
    "id": 249,
    "code": "-",
    "name": "Filet de dinde 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771844681/product/e3ae9c1c57ea216dbb5f2eef0a983a0b.webp",
    "isEnabled": true
  },
  {
    "id": 250,
    "code": "7127",
    "name": "Filet de dinde fumé 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2623454001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773220486/product/a8892fa69d67bab50696c3e65645c609.webp",
    "isEnabled": true
  },
  {
    "id": 251,
    "code": "6174",
    "name": "Filet de dinde fumé en tranches 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641584001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783607607/product/57a8165975c9c9fdb2cfb32fbbf689de.webp",
    "isEnabled": true
  },
  {
    "id": 252,
    "code": "-",
    "name": "Filet de dinde mavi 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771845112/product/2bfe5abebcc29a662abd5eceef97ead9.webp",
    "isEnabled": true
  },
  {
    "id": 253,
    "code": "-",
    "name": "Galantine de canard bleu noix 100g - AGHBALOU",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773661423/product/e34232f0c42d0af8b319341a0a06503c.webp",
    "isEnabled": true
  },
  {
    "id": 254,
    "code": "-",
    "name": "Galantine de canard pistaches 100g - AGHBALOU",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773661744/product/ed1900995e1eee8b5fd67759ae4f6ca4.webp",
    "isEnabled": true
  },
  {
    "id": 255,
    "code": "-",
    "name": "Galantine de canard tradition 100g - AGHBALOU",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014796706",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773660892/product/4ab4aeb40356e6130f5370b4b2f53192.webp",
    "isEnabled": true
  },
  {
    "id": 256,
    "code": "-",
    "name": "Galantine de poulet aux oignons 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773396686/product/833cbd8d2826a4a7c426c14a37664e03.webp",
    "isEnabled": true
  },
  {
    "id": 257,
    "code": "-",
    "name": "Galantine de poulet aux poivres 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776166353/product/b689141d083e20a79e3964a7c37873a3.webp",
    "isEnabled": true
  },
  {
    "id": 258,
    "code": "-",
    "name": "Jambon cuisse aux poivres 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773396237/product/3947f03709683788dc358537c8a5b528.webp",
    "isEnabled": true
  },
  {
    "id": 259,
    "code": "-",
    "name": "Jambon cuisse nature 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773396435/product/fc97bc3b7f10c2f023c2d3bdf8253ac1.webp",
    "isEnabled": true
  },
  {
    "id": 260,
    "code": "-",
    "name": "Jambon cuit fumé 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771849756/product/13f07970070f1db106a30aa019d3b3e2.webp",
    "isEnabled": true
  },
  {
    "id": 261,
    "code": "-",
    "name": "Jambon cuit supérieur 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014794443",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783678560/product/1dca51bca7a07a5c48b3c154725498a6.webp",
    "isEnabled": true
  },
  {
    "id": 262,
    "code": "3255",
    "name": "Jambon de bœuf en tranches 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641650001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783607959/product/a036d9fb2822f7626177113dc20d0b49.webp",
    "isEnabled": true
  },
  {
    "id": 263,
    "code": "2498",
    "name": "Jambon de bœuf fumé en tranches 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2675438001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1693600467/product/137f74318563ce3bc1822379f55885d7.webp",
    "isEnabled": true
  },
  {
    "id": 264,
    "code": "-",
    "name": "Jambon de bœuf suprême 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771845355/product/55ae422bf93eb4b50ce86e5a6f9ec7b6.webp",
    "isEnabled": true
  },
  {
    "id": 265,
    "code": "-",
    "name": "Jambon de dinde aux fines herbes 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014794160",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783678720/product/77e9bd45e5e0be53ec182aaf351543c2.webp",
    "isEnabled": true
  },
  {
    "id": 266,
    "code": "7825",
    "name": "Jambon de dinde fumé 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2623455001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_240/v1773223056/product/f1a1535b3713f62c547fdeafe1bf5275.webp",
    "isEnabled": true
  },
  {
    "id": 267,
    "code": "9804",
    "name": "Jambon de dinde fumé en tranches 100g - MAVI",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641185001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1790164803/product/3cdc435e5cfc1047a7092b9672e7c316.webp",
    "isEnabled": true
  },
  {
    "id": 268,
    "code": "-",
    "name": "Jambon de dinde paprika 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014794214",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771845665/product/0ab27a5ad2e7ae8d26ed8f157d6e0146.webp",
    "isEnabled": true
  },
  {
    "id": 269,
    "code": "-",
    "name": "Jambon duo fumé 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014794467",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783677873/product/2e7ce5ac0d1fe961282ac10829cf6cf2.webp",
    "isEnabled": true
  },
  {
    "id": 270,
    "code": "-",
    "name": "Jambon filet aux herbes 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014796447",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776853002/product/3f7622df7515fd931d33ac5a08449ef2.webp",
    "isEnabled": true
  },
  {
    "id": 271,
    "code": "-",
    "name": "Jambon filet aux poivres 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773220486/product/a8892fa69d67bab50696c3e65645c609.webp",
    "isEnabled": true
  },
  {
    "id": 272,
    "code": "-",
    "name": "Jambon filet nature 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773396066/product/f586621a6bcc83b4518a0d8a1bca9c87.webp",
    "isEnabled": true
  },
  {
    "id": 273,
    "code": "-",
    "name": "Kacher aux olives 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781277450/product/0725b596bf1d779776380ca9ee7de7b9.webp",
    "isEnabled": true
  },
  {
    "id": 274,
    "code": "-",
    "name": "Kacher nature 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014794474",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783607385/product/0182b3d2936415f9aaf5ba5c28524cf6.webp",
    "isEnabled": true
  },
  {
    "id": 275,
    "code": "-",
    "name": "Kacher piquant 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781277354/product/cebca067ca3269d8fecdb4180e547351.webp",
    "isEnabled": true
  },
  {
    "id": 276,
    "code": "-",
    "name": "Marbré de poulet 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771846374/product/aadf68bb4043d59147b8b235db3ed76a.webp",
    "isEnabled": true
  },
  {
    "id": 277,
    "code": "-",
    "name": "Mortadelle fine aux herbes 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783506728/product/4baa4eed5a10d415b012a487cb395512.webp",
    "isEnabled": true
  },
  {
    "id": 278,
    "code": "-",
    "name": "Mortadelle fromage 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783506343/product/2d02a58c69267eea7b050b8aa247b0fd.webp",
    "isEnabled": true
  },
  {
    "id": 279,
    "code": "6018",
    "name": "Mortadelle italienne de canard 100g - AGHBALOU",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014796737",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776853781/product/1692532869d1371a9ecc9ec6e91b6d44.webp",
    "isEnabled": true
  },
  {
    "id": 280,
    "code": "-",
    "name": "Mousse de foie 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773660616/product/732272ca4913dd5dc00f4724dbcd2578.webp",
    "isEnabled": true
  },
  {
    "id": 281,
    "code": "-",
    "name": "Mousse de poulet au piment 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014796676",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776855136/product/3e8900a18ddae5b0ba3dd37a396f098c.webp",
    "isEnabled": true
  },
  {
    "id": 282,
    "code": "-",
    "name": "Mousse forestière 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776166244/product/5055c2ea35bd252eac904f4df033f71e.webp",
    "isEnabled": true
  },
  {
    "id": 283,
    "code": "1580",
    "name": "Pepperoni 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2610967001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783508012/product/712b181f5a4a0fa76fc063ab4fea1267.webp",
    "isEnabled": true
  },
  {
    "id": 284,
    "code": "-",
    "name": "Pepperoni 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771844120/product/4df25596c77265591eb8e29dbf16432b.webp",
    "isEnabled": true
  },
  {
    "id": 285,
    "code": "2536",
    "name": "Rosbeef en tranches 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641580001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783608858/product/51d17c06ae2c3d061e7cd364cfafadb9.webp",
    "isEnabled": true
  },
  {
    "id": 286,
    "code": "8857",
    "name": "Rosette de dinde en tranches 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641858001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783672821/product/e2a4f208fdf956c5345a087380e7591a.webp",
    "isEnabled": true
  },
  {
    "id": 287,
    "code": "7152",
    "name": "Rosette de dinde fumé 100g - MARJANE",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2624452001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1773221269/product/63c7fb2dd34b7cc58af638d652df02ee.webp",
    "isEnabled": true
  },
  {
    "id": 288,
    "code": "-",
    "name": "Roulade 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783672558/product/f360cf7bbf90484758d9109034437683.webp",
    "isEnabled": true
  },
  {
    "id": 289,
    "code": "4270",
    "name": "Roulé de Surimi en morceau 100g - COPRALIM",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641593001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1614675233/product_optimized/a378bac5a28b370eeed0b31d793a7d43.webp",
    "isEnabled": true
  },
  {
    "id": 290,
    "code": "-",
    "name": "Roulé de Surimi en tranches 100g - COPRALIM",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1614675364/product_optimized/3977ad4bcfec1f5dd724534587262f61.webp",
    "isEnabled": true
  },
  {
    "id": 291,
    "code": "8854",
    "name": "Salami de bœuf en tranches 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2641854001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783609026/product/f9931c5ed777255e83efd06b6fa6eca7.webp",
    "isEnabled": true
  },
  {
    "id": 292,
    "code": "4522",
    "name": "Salami de bœuf en tranches 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2541260010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783672096/product/e9f04ce5a4b6791c1c09a52cc4a0986c.webp",
    "isEnabled": true
  },
  {
    "id": 293,
    "code": "-",
    "name": "Salami de dinde 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783507067/product/703c186461dc7c7b701ca56448d2a8d1.webp",
    "isEnabled": true
  },
  {
    "id": 294,
    "code": "-",
    "name": "Saucisson de bœuf nature 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771846858/product/321bf2312c383424fb8ee972d5add187.webp",
    "isEnabled": true
  },
  {
    "id": 295,
    "code": "-",
    "name": "Saucisson de bœuf piquant 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771846921/product/c47d0131efa48564dbda4400832f0d93.webp",
    "isEnabled": true
  },
  {
    "id": 296,
    "code": "-",
    "name": "Saucisson fumé à l'ail 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783678915/product/7e37fd8ad3bc1569aeacee5e6bfe1325.webp",
    "isEnabled": true
  },
  {
    "id": 297,
    "code": "-",
    "name": "Suprême de dinde paprika 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783679200/product/a0f275f323ae5b8d9e8c52110f77df8e.webp",
    "isEnabled": true
  },
  {
    "id": 298,
    "code": "-",
    "name": "Suprême Filet Herbes 100g - DINDY",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783676774/product/f2d0d6c0545c9f704bad1e17d838f3d7.webp",
    "isEnabled": true
  },
  {
    "id": 299,
    "code": "-",
    "name": "Surimi aux crevettes 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771847129/product/219711b5f686e33b3687f8eeacbe9377.webp",
    "isEnabled": true
  },
  {
    "id": 300,
    "code": "-",
    "name": "Surimi en mosaïque crabe 100g - DEL PACHA",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeSecours": "2000014794184",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771846984/product/8d5ad196d23004ebb8c203b704562ff5.webp",
    "isEnabled": true
  },
  {
    "id": 301,
    "code": "-",
    "name": "Surimi saveur crabe 100g",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1771847067/product/27e0d8730456e241b4c7bc47744da904.webp",
    "isEnabled": true
  },
  {
    "id": 302,
    "code": "3553",
    "name": "Terrine de campagne de poulet au poivre 100g - ANDALOUS",
    "department": "Fromage et charcuterie",
    "category": "Charcuterie",
    "barcodeMjValide": "2654740001000",
    "barcodeSecours": "2000014796508",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1776854285/product/885197caf8690aa63b6e403ce776466f.webp",
    "isEnabled": true
  },
  {
    "id": 303,
    "code": "XXXX",
    "name": "Abricot ferme au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2626421005000",
    "isEnabled": true
  },
  {
    "id": 304,
    "code": "2458",
    "name": "Abricot golden calibre 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2666112005000",
    "isEnabled": true
  },
  {
    "id": 305,
    "code": "XXXX",
    "name": "Abricot petit kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2666721005000",
    "isEnabled": true
  },
  {
    "id": 306,
    "code": "5169",
    "name": "Ananas à la pièce",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624265000018",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1760003973/product/2edbaa21f81fe6fac9fe546b3109bad6.webp",
    "isEnabled": true
  },
  {
    "id": 307,
    "code": "8047",
    "name": "Avocat 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624094005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789743642/product/a9d11d0275814cf69a59a4646bdebd8f.webp",
    "isEnabled": true
  },
  {
    "id": 308,
    "code": "-",
    "name": "Avocat extra 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789743687/product/0940fb91b2e3e24aa5d211ea008e6ab1.webp",
    "isEnabled": true
  },
  {
    "id": 309,
    "code": "XXXX",
    "name": "Avocat filière au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2621099010000",
    "isEnabled": true
  },
  {
    "id": 310,
    "code": "1171",
    "name": "Avocat Hass 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2600303005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1698916413/product/7509efb91b22fc7ea1182c6b1fbab528.webp",
    "isEnabled": true
  },
  {
    "id": 311,
    "code": "-",
    "name": "Baby mangue 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671183467/product_optimized/2379347ca632dfed8843f95b1b3adb9e.webp",
    "isEnabled": true
  },
  {
    "id": 312,
    "code": "2329",
    "name": "Baby pastèque marhoum environ 1,5Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2690020015000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1625821436/product_optimized/311f1f28a5f10f56973515a17f9ef57b.webp",
    "isEnabled": true
  },
  {
    "id": 313,
    "code": "1240",
    "name": "Banane 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624507010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587300488/product_optimized/86199d6fb1d0ee856ae27fb67edb795d.webp",
    "isEnabled": true
  },
  {
    "id": 314,
    "code": "-",
    "name": "Carambole 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671184958/product_optimized/c5f533a81995324c7f57d930781b1997.webp",
    "isEnabled": true
  },
  {
    "id": 315,
    "code": "3521",
    "name": "Cerise 500g - FILIER M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2607761005000",
    "isEnabled": true
  },
  {
    "id": 316,
    "code": "XXXX",
    "name": "Cerise locale au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624600005000",
    "isEnabled": true
  },
  {
    "id": 317,
    "code": "547",
    "name": "Citron jaune 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624805005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587300561/product_optimized/29e5fb4b89dd884f9ee032e3729d00a0.webp",
    "isEnabled": true
  },
  {
    "id": 318,
    "code": "-",
    "name": "Citron jaune filet 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781165114/product/a231f340bd80e2b2bf2e6a6b58794f22.webp",
    "isEnabled": true
  },
  {
    "id": 319,
    "code": "7887",
    "name": "Citron lime 1kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624288010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789468998/product/40112d003b8bfdb2333f4d6aaff89f50.webp",
    "isEnabled": true
  },
  {
    "id": 320,
    "code": "1437",
    "name": "Citron vert 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624125005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1631865179/product_optimized/bbefb892fffcce20ad39079bae65a1b2.webp",
    "isEnabled": true
  },
  {
    "id": 321,
    "code": "XXXX",
    "name": "Citron vert le kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1631865179/product_optimized/bbefb892fffcce20ad39079bae65a1b2.webp",
    "isEnabled": true
  },
  {
    "id": 322,
    "code": "7768",
    "name": "Clémentine 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2657651010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761217557/product/2a5d30f533cf6df6b707581a42800e01.webp",
    "isEnabled": true
  },
  {
    "id": 323,
    "code": "-",
    "name": "Coing 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751385264/product/ca22f45dd80a7d9d44fa8363c1148273.webp",
    "isEnabled": true
  },
  {
    "id": 324,
    "code": "XXXX",
    "name": "Courge orange au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2605054005000",
    "isEnabled": true
  },
  {
    "id": 325,
    "code": "-",
    "name": "Framboise en barquette de 125g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMiniSecours": "8717496041647",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1758897353/product/3a24d1897a8b8a35870ed90392cb120a.webp",
    "isEnabled": true
  },
  {
    "id": 326,
    "code": "9256",
    "name": "Fruit de la passion 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2626328001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1765291362/product/382865592e1d94dcbb04adec1f79ad13.webp",
    "isEnabled": true
  },
  {
    "id": 327,
    "code": "9266",
    "name": "Goyave 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2626340001000",
    "isEnabled": true
  },
  {
    "id": 328,
    "code": "-",
    "name": "Grandilla 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "isEnabled": true
  },
  {
    "id": 329,
    "code": "552",
    "name": "Grenade 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "isEnabled": true
  },
  {
    "id": 330,
    "code": "2780",
    "name": "Grenade 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2626286010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789030145/product/34c83b10df07ddeda9afd71d549375f1.webp",
    "isEnabled": true
  },
  {
    "id": 331,
    "code": "2383",
    "name": "Kaki 1kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2675410010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1792152052/product/a8d4322b82ddb9a388ec56630d8a0651.webp",
    "isEnabled": true
  },
  {
    "id": 332,
    "code": "4915",
    "name": "Kiwi gold 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2640036001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761217228/product/49144c4f14dd90d0c21075f9778fdc2f.webp",
    "isEnabled": true
  },
  {
    "id": 333,
    "code": "XXXX",
    "name": "Kiwi long au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624828005000",
    "isEnabled": true
  },
  {
    "id": 334,
    "code": "888",
    "name": "Kiwi moyen calibre 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624935005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783091444/product/69bd4d91333a22eb7c130fb2b43a19d6.webp",
    "isEnabled": true
  },
  {
    "id": 335,
    "code": "1085",
    "name": "Kumquat 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2670010001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785233203/product/fe643842c97479f0bcda627a622d9aef.webp",
    "isEnabled": true
  },
  {
    "id": 336,
    "code": "5820",
    "name": "Lulo 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2605441001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671183027/product_optimized/a387232e90330eeed168ac4f9549b21a.webp",
    "isEnabled": true
  },
  {
    "id": 337,
    "code": "9003",
    "name": "Mandarine afouer 1kg - FILIER M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2678651010000",
    "isEnabled": true
  },
  {
    "id": 338,
    "code": "-",
    "name": "Mandarine sweet 1kg - FILIER M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2699787009993",
    "isEnabled": true
  },
  {
    "id": 339,
    "code": "2846",
    "name": "Mangue 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2654829005000",
    "barcodeMarjane": "2605847010000",
    "barcodeMiniSecours": "41204030",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783504871/product/3b0884c980d01a366e7f8506f05abd51.webp",
    "isEnabled": true
  },
  {
    "id": 340,
    "code": "3821",
    "name": "Mangue 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2600210005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783504871/product/3b0884c980d01a366e7f8506f05abd51.webp",
    "isEnabled": true
  },
  {
    "id": 341,
    "code": "-",
    "name": "Mangue à la pièce",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMiniSecours": "30136724",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1676968599/product_optimized/6571423d8b4496dbe2c44dd5afa33082.webp",
    "isEnabled": true
  },
  {
    "id": 342,
    "code": "-",
    "name": "Mangue avion 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785250991/product/45342ba4e13e00569e6a1b7f6daca6c4.webp",
    "isEnabled": true
  },
  {
    "id": 343,
    "code": "-",
    "name": "Maracuya 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1765291028/product/bbd58df609b2b31672ed69f99e005f49.webp",
    "isEnabled": true
  },
  {
    "id": 344,
    "code": "XXXX",
    "name": "Melon ananas au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624437015000",
    "isEnabled": true
  },
  {
    "id": 345,
    "code": "-",
    "name": "Melon blanc marhoum environ 2Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1625821213/product_optimized/5d93eec25caf54120baf66d2795726cb.webp",
    "isEnabled": true
  },
  {
    "id": 346,
    "code": "8523",
    "name": "Melon jaune environ 1,5Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624887015000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756198879/product/f4a55ebe436b70f7e69ce488ce6846a8.webp",
    "isEnabled": true
  },
  {
    "id": 347,
    "code": "-",
    "name": "Melon jaune environ 1,5Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624885015000",
    "isEnabled": true
  },
  {
    "id": 348,
    "code": "4988",
    "name": "Melon sanchou environ 1,5Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2626677015000",
    "barcodeSecours": "2688714015000",
    "isEnabled": true
  },
  {
    "id": 349,
    "code": "XXXX",
    "name": "Melon souhila au",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2606060015000",
    "isEnabled": true
  },
  {
    "id": 350,
    "code": "8480",
    "name": "Melon souihla environ 1,5Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2606060015000",
    "isEnabled": true
  },
  {
    "id": 351,
    "code": "3005",
    "name": "Mûres, la barquette",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2600037000011",
    "barcodeMiniSecours": "40870090",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588264185/product_optimized/14900bdc1764521807da5b7fea70f3be.webp",
    "isEnabled": true
  },
  {
    "id": 352,
    "code": "XXXX",
    "name": "Nectarine blanche kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2627749005000",
    "isEnabled": true
  },
  {
    "id": 353,
    "code": "XXXX",
    "name": "Nectarine en barqyette",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeSecours": "2000014446410",
    "isEnabled": true
  },
  {
    "id": 354,
    "code": "7871",
    "name": "Nectarine gros calibre 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2677781005000",
    "isEnabled": true
  },
  {
    "id": 355,
    "code": "5878",
    "name": "Nectarine moyen calibre 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2677749005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1644598218/product_optimized/5d6504767182eafed69b67443a29dad3.webp",
    "isEnabled": true
  },
  {
    "id": 356,
    "code": "XXXX",
    "name": "Nèfle en vrac le kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeSecours": "2624921005000",
    "isEnabled": true
  },
  {
    "id": 357,
    "code": "-",
    "name": "Noix de coco à la pièce",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMiniSecours": "20283537",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1593425586/product_optimized/9ca8953df74330fe2997429efef4efc9.webp",
    "isEnabled": true
  },
  {
    "id": 358,
    "code": "590",
    "name": "Orange à jus 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624898010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756137252/product/e01df6c775efa93872f2fabbe040e362.webp",
    "isEnabled": true
  },
  {
    "id": 359,
    "code": "-",
    "name": "Orange à jus en filet 2Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMiniSecours": "23282100",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1738953631/product/e142ad29e89e743764191e490e67f4f0.webp",
    "isEnabled": true
  },
  {
    "id": 360,
    "code": "XXXX",
    "name": "Orange Cara Cara filière",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeSecours": "2604765010000",
    "isEnabled": true
  },
  {
    "id": 361,
    "code": "XXXX",
    "name": "Orange navel à feuil",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeSecours": "2624390010000",
    "isEnabled": true
  },
  {
    "id": 362,
    "code": "3746",
    "name": "Pamplemousse 500g",
    "department": "Fruits et légumes",
    "category": "Général",
    "barcodeMjValide": "2600649005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587303039/product_optimized/a2e85cc730915ff1859de62abd18411f.webp",
    "isEnabled": true
  },
  {
    "id": 363,
    "code": "-",
    "name": "Pamplemousse 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2628684005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587303039/product_optimized/a2e85cc730915ff1859de62abd18411f.webp",
    "isEnabled": true
  },
  {
    "id": 364,
    "code": "XXXX",
    "name": "Pamplemousse rose au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2600649010000",
    "isEnabled": true
  },
  {
    "id": 365,
    "code": "XXXX",
    "name": "Papaye 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624099010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1644598218/product_optimized/5d6504767182eafed69b67443a29dad3.webp",
    "isEnabled": true
  },
  {
    "id": 366,
    "code": "XXXX",
    "name": "Pastèque",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "isEnabled": true
  },
  {
    "id": 367,
    "code": "5746",
    "name": "Pastèque 1kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624126010000",
    "isEnabled": true
  },
  {
    "id": 368,
    "code": "XXXX",
    "name": "Pastèque 8kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624512008000",
    "isEnabled": true
  },
  {
    "id": 369,
    "code": "-",
    "name": "Peach plate 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2676543010000",
    "isEnabled": true
  },
  {
    "id": 370,
    "code": "-",
    "name": "Peach plate 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2608589010000",
    "isEnabled": true
  },
  {
    "id": 371,
    "code": "XXXX",
    "name": "Pêche CALIBRE 20-25",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2627782005000",
    "barcodeSecours": "2624100005000",
    "isEnabled": true
  },
  {
    "id": 372,
    "code": "7868",
    "name": "Pêche moyen calibre 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2677782005000",
    "isEnabled": true
  },
  {
    "id": 373,
    "code": "-",
    "name": "Physalis en barquette",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1786357094/product/6ae665caafd21d6dceebbf344a85ab0d.webp",
    "isEnabled": true
  },
  {
    "id": 374,
    "code": "-",
    "name": "Pitaya jaune 300g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671184652/product_optimized/dfbc7eb8c8a804b06ec8fda4ae455637.webp",
    "isEnabled": true
  },
  {
    "id": 375,
    "code": "1540",
    "name": "Pitaya rouge 200g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2608938002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785232215/product/d041796b12902e658ca9a3969b7f34c7.webp",
    "isEnabled": true
  },
  {
    "id": 376,
    "code": "8139",
    "name": "Poire 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624034005000",
    "isEnabled": true
  },
  {
    "id": 377,
    "code": "6031",
    "name": "Poire ALJANDRINA 1kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2651325010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789469663/product/bc8709043c3b1dac27032917e88ea0cf.webp",
    "isEnabled": true
  },
  {
    "id": 378,
    "code": "XXXX",
    "name": "Poire au kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "isEnabled": true
  },
  {
    "id": 379,
    "code": "-",
    "name": "Poire conférence 1kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624854010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756199018/product/6eaea067d4bc367447724bb7bbe535da.webp",
    "isEnabled": true
  },
  {
    "id": 380,
    "code": "XXXX",
    "name": "Poire double couche",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2671714010000",
    "isEnabled": true
  },
  {
    "id": 381,
    "code": "7715",
    "name": "Poire Flor 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2671714005000",
    "isEnabled": true
  },
  {
    "id": 382,
    "code": "XXXX",
    "name": "Poire le kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624129010000",
    "isEnabled": true
  },
  {
    "id": 383,
    "code": "-",
    "name": "Poire muscat 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "3671714005000",
    "isEnabled": true
  },
  {
    "id": 384,
    "code": "7715",
    "name": "Poire rocha 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2671714010000",
    "barcodeMarjane": "2624129010000",
    "barcodeSecours": "2000014450820",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756198925/product/4d3b06d55b774f4b5d8d44cf2f359bcf.webp",
    "isEnabled": true
  },
  {
    "id": 385,
    "code": "-",
    "name": "Poire rouge",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2627788005000",
    "isEnabled": true
  },
  {
    "id": 386,
    "code": "5744",
    "name": "Poire Williams 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2600526010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756198975/product/46ee46d1a24c0c22f5b506d43400fe9b.webp",
    "isEnabled": true
  },
  {
    "id": 387,
    "code": "-",
    "name": "Pomme cocktail x6 pièces - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1762267116/product/3e61d3e5173088e2cf5ea39714e1b8fb.webp",
    "isEnabled": true
  },
  {
    "id": 388,
    "code": "9071",
    "name": "Pomme de terre douce orange 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2608762005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789743857/product/b5f5f94a3a9bd789adbbf3dccd3b1d10.webp",
    "isEnabled": true
  },
  {
    "id": 389,
    "code": "4105",
    "name": "Pomme gala gros calibre 18-20 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2604465010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751383743/product/905548a528121c71ddc0069415c12a60.webp",
    "isEnabled": true
  },
  {
    "id": 390,
    "code": "XXXX",
    "name": "Pomme gala moyen calibre 14-22 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2604444010000",
    "isEnabled": true
  },
  {
    "id": 391,
    "code": "XXXX",
    "name": "Pomme gala moyen calibre 24-28 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2604443010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761216618/product/5b64b4b305a6ffcd5a9830a49c5672ca.webp",
    "isEnabled": true
  },
  {
    "id": 392,
    "code": "-",
    "name": "Pomme gala Sachet 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381332/product/b7ffe3c80c3a3b93824dfc559106f637.webp",
    "isEnabled": true
  },
  {
    "id": 393,
    "code": "8457",
    "name": "Pomme golden calibre 18-20 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624497010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1623227248/product_optimized/1462752b54985823ec791b82cf633a47.webp",
    "isEnabled": true
  },
  {
    "id": 394,
    "code": "4104",
    "name": "Pomme golden moyen calibre 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2604446010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1704724326/product/f24cf3c327f7ac29a54e88bb5a1d3c9f.webp",
    "isEnabled": true
  },
  {
    "id": 395,
    "code": "8541",
    "name": "Pomme golden moyen calibre 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2604453010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1704724326/product/f24cf3c327f7ac29a54e88bb5a1d3c9f.webp",
    "isEnabled": true
  },
  {
    "id": 396,
    "code": "XXXX",
    "name": "Pomme golden simple",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "isEnabled": true
  },
  {
    "id": 397,
    "code": "XXXX",
    "name": "Pomme granny calibre 18-20 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761217938/product/f7f20d8be4cb1441e0fa8d3caa23a668.webp",
    "isEnabled": true
  },
  {
    "id": 398,
    "code": "XXXX",
    "name": "Pomme rouge 24-28 f — moyen",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2605570010000",
    "isEnabled": true
  },
  {
    "id": 399,
    "code": "XXXX",
    "name": "Pomme rouge calibre 18-20 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2604465010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1698916506/product/6fb3debc9328873be88b590488e86f59.webp",
    "isEnabled": true
  },
  {
    "id": 400,
    "code": "XXXX",
    "name": "Pomme rouge simple c extra",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2624994010000",
    "isEnabled": true
  },
  {
    "id": 401,
    "code": "-",
    "name": "Pomme royal gala calibre 18-20 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761216727/product/4dd487506a8794052810bb41efd9bc10.webp",
    "isEnabled": true
  },
  {
    "id": 402,
    "code": "-",
    "name": "Prune jaune en barquette 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeSecours": "2000014276376",
    "isEnabled": true
  },
  {
    "id": 403,
    "code": "-",
    "name": "Prune jaune grand calibre 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2607071005000",
    "isEnabled": true
  },
  {
    "id": 404,
    "code": "XXXX",
    "name": "Prune jaune mi-fille",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2677705005004",
    "isEnabled": true
  },
  {
    "id": 405,
    "code": "7856",
    "name": "Prune jaune moyen calibre 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2607775005000",
    "isEnabled": true
  },
  {
    "id": 406,
    "code": "-",
    "name": "Prune rouge 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMiniSecours": "41159682",
    "isEnabled": true
  },
  {
    "id": 407,
    "code": "7866",
    "name": "Prune rouge moyen calibre 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2677787005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756217545/product/8effe6baf6c0d4686765e4f0c7fe3cfd.webp",
    "isEnabled": true
  },
  {
    "id": 408,
    "code": "-",
    "name": "Prune rouge gros calibre 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Général",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756198698/product/33e06c04f538f2bf68f1e91f7a842dd2.webp",
    "isEnabled": true
  },
  {
    "id": 409,
    "code": "6365",
    "name": "Raisin blanc 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624120010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1727807765/product/c241afeda9957a6171ec78dac4485c23.webp",
    "isEnabled": true
  },
  {
    "id": 410,
    "code": "558",
    "name": "Raisin blanc 1Kg",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624602010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1727807765/product/c241afeda9957a6171ec78dac4485c23.webp",
    "isEnabled": true
  },
  {
    "id": 411,
    "code": "6365",
    "name": "Raisin blanc 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2624120010000",
    "barcodeMiniSecours": "41239094",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1727807765/product/c241afeda9957a6171ec78dac4485c23.webp",
    "isEnabled": true
  },
  {
    "id": 412,
    "code": "XXXX",
    "name": "Raisin blanc sans pépins 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMarjane": "2685219010000",
    "isEnabled": true
  },
  {
    "id": 413,
    "code": "5324",
    "name": "Raisin blanc snisla 500g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2626906005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785234177/product/afbf64bac8ef6da99f642131a247626d.webp",
    "isEnabled": true
  },
  {
    "id": 414,
    "code": "4994",
    "name": "Raisin mpalleri 1Kg - FILIER M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2641369010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1786007947/product/c1a18f06798716a87b5e5123595983c7.webp",
    "isEnabled": true
  },
  {
    "id": 415,
    "code": "4994",
    "name": "Raisin noir 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2641369010000",
    "barcodeMarjane": "2624602010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1786007947/product/c1a18f06798716a87b5e5123595983c7.webp",
    "isEnabled": true
  },
  {
    "id": 416,
    "code": "8095",
    "name": "Raisin red globe 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2641618010000",
    "barcodeSecours": "2000014695726",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751384984/product/272f7b00cff864172be5b20be6543344.webp",
    "isEnabled": true
  },
  {
    "id": 417,
    "code": "-",
    "name": "Rambutan 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671183167/product_optimized/91100934a32f4faf2ae5b53fff9687fc.webp",
    "isEnabled": true
  },
  {
    "id": 418,
    "code": "3671",
    "name": "Salak 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2626285001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785232681/product/0e025b363102aaf9c47e3a675be4c769.webp",
    "isEnabled": true
  },
  {
    "id": 419,
    "code": "-",
    "name": "Tamarillo 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1765291678/product/eacb62ae08fec969d0a1b28bc2741720.webp",
    "isEnabled": true
  },
  {
    "id": 420,
    "code": "2845",
    "name": "Tamarin 100g",
    "department": "Fruits et légumes",
    "category": "Fruits",
    "barcodeMjValide": "2658910001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785250564/product/992af406298a87ca243e3f20cdb844e8.webp",
    "isEnabled": true
  },
  {
    "id": 421,
    "code": "-",
    "name": "Basilic en barquette 25g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014488199",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747929324/product/6d0b1739b702a7404bd421fb8c8652d5.webp",
    "isEnabled": true
  },
  {
    "id": 422,
    "code": "6576",
    "name": "Bok choy 100g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2626291001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671186894/product_optimized/94a308d1a9b90386df05246313464ae6.webp",
    "isEnabled": true
  },
  {
    "id": 423,
    "code": "-",
    "name": "Céleri en sachet de 110g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747827232/product/518dba49296f5785fa11b7ce7f68b9a5.webp",
    "isEnabled": true
  },
  {
    "id": 424,
    "code": "-",
    "name": "Celerie branche",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1783424654/product/80b99db72dee5efbd46202e75b0a2b19.webp",
    "isEnabled": true
  },
  {
    "id": 425,
    "code": "-",
    "name": "Choux chinois 1Kg",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671185240/product_optimized/34476948422b8293f1510b88123f14f7.webp",
    "isEnabled": true
  },
  {
    "id": 426,
    "code": "-",
    "name": "Choux romanesco à la pièce",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671184814/product_optimized/130cf69bf1c9aca3debc0f26476b492a.webp",
    "isEnabled": true
  },
  {
    "id": 427,
    "code": "-",
    "name": "Ciboulette en barquette 25g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756132290/product/21969dfa9031ae2760afc7dc52ddb3d5.webp",
    "isEnabled": true
  },
  {
    "id": 428,
    "code": "-",
    "name": "Coriandre en sachet - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014033573",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747929242/product/6e9b2007af0b7d17436f702576ba6e0e.webp",
    "isEnabled": true
  },
  {
    "id": 429,
    "code": "588",
    "name": "Epinard 500g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2624896005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1620743146/product_optimized/c9f27627dace517b54f0bc621042d704.webp",
    "isEnabled": true
  },
  {
    "id": 430,
    "code": "-",
    "name": "Jeune pousse de betterave 100g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747753895/product/5f2d5c711dac1ebab1ca8459bc2221fa.webp",
    "isEnabled": true
  },
  {
    "id": 431,
    "code": "9871",
    "name": "Laitue batavia rouge à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2624567000010",
    "imageUrl": "https://biotop.ma/cdn/shop/products/batavia-rouge-bio-piece.jpg?v=1653585320",
    "isEnabled": true
  },
  {
    "id": 432,
    "code": "9872",
    "name": "Laitue batavia verte à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2678965000010",
    "barcodeSecours": "2000014624375",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1758038593/product/eef269862ad22f4160902c841175fb72.webp",
    "isEnabled": true
  },
  {
    "id": 433,
    "code": "9894",
    "name": "Laitue feuille de chêne rouge à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2611557000018",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1728999090/product/1e8255b9c1bbe9ea2493799169ca8f57.webp",
    "isEnabled": true
  },
  {
    "id": 434,
    "code": "6965",
    "name": "Laitue feuille de chêne verte à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2687715000010",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1786094745/product/fe19cfbad319ab0ff6fec9dbf9ca402e.webp",
    "isEnabled": true
  },
  {
    "id": 435,
    "code": "9879",
    "name": "Laitue frisée à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2569827600010",
    "isEnabled": true
  },
  {
    "id": 436,
    "code": "3182",
    "name": "Laitue iceberg à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2669006000018",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1729082783/product/18f9d4d0d8ae9e8041449acee9f92d63.webp",
    "isEnabled": true
  },
  {
    "id": 437,
    "code": "1755",
    "name": "Laitue lolo rouge à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2669003000018",
    "barcodeSecours": "2000014624429",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751452720/product/c9655b2ab314a5077d96d21bd2836b04.webp",
    "isEnabled": true
  },
  {
    "id": 438,
    "code": "-",
    "name": "Laitue lolo verte à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2669002000018",
    "barcodeSecours": "2000014624436",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1762526529/product/5c8036490b1b19b8c7e44a041a6b9e4a.webp",
    "isEnabled": true
  },
  {
    "id": 439,
    "code": "9884",
    "name": "Laitue romaine à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2698274000014",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751384691/product/13fbc028197c8139809545238822cd73.webp",
    "isEnabled": true
  },
  {
    "id": 440,
    "code": "6966",
    "name": "Laitue rouge à la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2686415000016",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756112301/product/cd566e4400f29d1a47475d1ae0069ab3.webp",
    "isEnabled": true
  },
  {
    "id": 441,
    "code": "6955",
    "name": "Laitue verte, la pièce - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2647851000018",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751449234/product/a6400bf0c8e03c1b88eb9cff913ad9ab.webp",
    "isEnabled": true
  },
  {
    "id": 442,
    "code": "-",
    "name": "Mâche 100g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014488137",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1741693771/product/3f49a03f59a6579c0a5a072e4ea58490.webp",
    "isEnabled": true
  },
  {
    "id": 443,
    "code": "-",
    "name": "Menthe en sachet - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014033559",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747928884/product/717a329fd5fd594d74ff7380ecbc1eb3.webp",
    "isEnabled": true
  },
  {
    "id": 444,
    "code": "-",
    "name": "Persil en sachet - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014033566",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747929206/product/55b53ebf2675c93c2ac2050b46a03b7b.webp",
    "isEnabled": true
  },
  {
    "id": 445,
    "code": "-",
    "name": "Romarin en barquette de 25g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014488311",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756133903/product/96151d39c2de6f4073c6fe95ddc923fc.webp",
    "isEnabled": true
  },
  {
    "id": 446,
    "code": "-",
    "name": "Roquette 100g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeSecours": "2000014488151",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1741693961/product/96cb55ff7fef154a1187b0b1eac45f24.webp",
    "isEnabled": true
  },
  {
    "id": 447,
    "code": "-",
    "name": "Salade mesclun 100g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1747753450/product/96e437ecfcf9213dc5b11b838b1eb18e.webp",
    "isEnabled": true
  },
  {
    "id": 448,
    "code": "557",
    "name": "Salade sucrine à la pièce",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMjValide": "2624603000014",
    "barcodeSecours": "2000014562219",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789476051/product/8c2fba40b65150de3d836794385da990.webp",
    "isEnabled": true
  },
  {
    "id": 449,
    "code": "-",
    "name": "Sauge en barquette de 25g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1746545309/product/39f3ad23769e124e935cc0d45609af7e.webp",
    "isEnabled": true
  },
  {
    "id": 450,
    "code": "-",
    "name": "Thym en barquette 25g",
    "department": "Fruits et légumes",
    "category": "Herbes et salades",
    "barcodeMarjane": "2000014488359",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1756133828/product/fa29fa74ba14c1f7e342dcac709b69f4.webp",
    "isEnabled": true
  },
  {
    "id": 451,
    "code": "-",
    "name": "Ail 250g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeSecours": "2000014764354",
    "barcodeMiniSecours": "22389701",
    "barcodeP3": "2000014758117",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1761732054/product/1559e82f6865c11ace9198c172bf7182.webp",
    "isEnabled": true
  },
  {
    "id": 452,
    "code": "-",
    "name": "Ail en filet gros calibre x 3 bulbes - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeSecours": "2000014245372",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751383153/product/6029da71cefdc0f9d6b57a7082a1c898.webp",
    "isEnabled": true
  },
  {
    "id": 453,
    "code": "-",
    "name": "Ail en filet gros calibre x 6 bulbes - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeSecours": "2000014245389",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1730105129/product/94347566c43729e5c5b040ee407f660a.webp",
    "isEnabled": true
  },
  {
    "id": 454,
    "code": "525",
    "name": "Artichaut vert 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624867010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588267594/product_optimized/d10691fd9239028c52bd1c9216f1da2a.webp",
    "isEnabled": true
  },
  {
    "id": 455,
    "code": "XXXX",
    "name": "Artichaut vert 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624487010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_240/v1588267594/product_optimized/d10691fd9239028c52bd1c9216f1da2a.webp",
    "isEnabled": true
  },
  {
    "id": 456,
    "code": "XXXX",
    "name": "Artichauts verts / kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624867010000",
    "isEnabled": true
  },
  {
    "id": 457,
    "code": "XXXX",
    "name": "Artichauts violets / kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624444010000",
    "isEnabled": true
  },
  {
    "id": 458,
    "code": "3325",
    "name": "Asperges en botte",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624851000010",
    "isEnabled": true
  },
  {
    "id": 459,
    "code": "2425",
    "name": "Aubergine ronde 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2677703005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381518/product/bfd2e025dba74f0ffadcbce8bcb7b0d6.webp",
    "isEnabled": true
  },
  {
    "id": 460,
    "code": "XXXX",
    "name": "Aubergine rouge le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624523005000",
    "isEnabled": true
  },
  {
    "id": 461,
    "code": "1207",
    "name": "Betterave 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2600010005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1781260887/product/7ec986b9598aae9a5d716d04290dba68.webp",
    "isEnabled": true
  },
  {
    "id": 462,
    "code": "2788",
    "name": "Brocoli 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624698005000",
    "isEnabled": true
  },
  {
    "id": 463,
    "code": "XXXX",
    "name": "Brocolis le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "isEnabled": true
  },
  {
    "id": 464,
    "code": "6188",
    "name": "Carotte 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2604124010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751384253/product/b28ff07f7228de6c76050425bf4ebef9.webp",
    "isEnabled": true
  },
  {
    "id": 465,
    "code": "566",
    "name": "Carotte jaune 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624594001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671186084/product_optimized/9b7e000eab9dd35d6002fee040b66bc3.webp",
    "isEnabled": true
  },
  {
    "id": 466,
    "code": "-",
    "name": "Carotte noir 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1671183860/product_optimized/d79327924f9dd9468f35d16000cd9c53.webp",
    "isEnabled": true
  },
  {
    "id": 467,
    "code": "512",
    "name": "Céleri-rave 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1765290659/product/6d5c4f8c3b7c23234d87606b5a5d0568.webp",
    "isEnabled": true
  },
  {
    "id": 468,
    "code": "9327",
    "name": "Champignon brown shimeji 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2607891001000",
    "isEnabled": true
  },
  {
    "id": 469,
    "code": "597",
    "name": "Champignon de paris 200g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2687871002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1690029284/product/6020186f3cabc8832435c094098dc0f1.webp",
    "isEnabled": true
  },
  {
    "id": 470,
    "code": "XXXX",
    "name": "Champignon frais 200g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624916002000",
    "isEnabled": true
  },
  {
    "id": 471,
    "code": "2856",
    "name": "Champignon koren 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2654127001000",
    "isEnabled": true
  },
  {
    "id": 472,
    "code": "2932",
    "name": "Champignon pied mouton 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2681238001000",
    "isEnabled": true
  },
  {
    "id": 473,
    "code": "754",
    "name": "Champignon Portobello 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624107001000",
    "isEnabled": true
  },
  {
    "id": 474,
    "code": "5408",
    "name": "Champignon white shimeji 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624716001000",
    "isEnabled": true
  },
  {
    "id": 475,
    "code": "XXXX",
    "name": "Chou blanc / kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624811010000",
    "isEnabled": true
  },
  {
    "id": 476,
    "code": "XXXX",
    "name": "Chou-fleur / kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624800010000",
    "isEnabled": true
  },
  {
    "id": 477,
    "code": "1876",
    "name": "Choux blanc 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2666884010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381582/product/9e8c0be84252039eb6c72018676c75c8.webp",
    "isEnabled": true
  },
  {
    "id": 478,
    "code": "1888",
    "name": "Choux rouge 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381630/product/5fa1c27f3757ebbecdb9a42561a0f84f.webp",
    "isEnabled": true
  },
  {
    "id": 479,
    "code": "XXXX",
    "name": "Concombre court / kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624589010000",
    "isEnabled": true
  },
  {
    "id": 480,
    "code": "2423",
    "name": "Concombre court 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2677702010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381669/product/19ff0e3435d88d9be6e244715a7710a5.webp",
    "isEnabled": true
  },
  {
    "id": 481,
    "code": "8307",
    "name": "Courge butternut environ 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2658497010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1784124168/product/76fdd400242f66f32d9f9fc3b57decac.webp",
    "isEnabled": true
  },
  {
    "id": 482,
    "code": "523",
    "name": "Courge rouge 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624869005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587309358/product_optimized/dc585873a77cff5e776e9158b073126e.webp",
    "isEnabled": true
  },
  {
    "id": 483,
    "code": "2994",
    "name": "Courgette blanche 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2626267005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751448109/product/9ab9f50e0502890f0370cfe84bd7a7c2.webp",
    "isEnabled": true
  },
  {
    "id": 484,
    "code": "1081",
    "name": "Courgette ronde 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2670006005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1620743036/product_optimized/6b2864cad56139e1bf04ae1bcdba9768.webp",
    "isEnabled": true
  },
  {
    "id": 485,
    "code": "-",
    "name": "Courgette slaoui 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMiniSecours": "41238134",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587309651/product_optimized/89925bd049a850b0f5cac8da90e4eba4.webp",
    "isEnabled": true
  },
  {
    "id": 486,
    "code": "-",
    "name": "Curcuma 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1765290830/product/bcb06b7f184911fd5caf65cb648b4747.webp",
    "isEnabled": true
  },
  {
    "id": 487,
    "code": "1410",
    "name": "Echalotes en filet 200g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2600625002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1790941180/product/7fa47c0a29d056cbdf35bb93c6798a84.webp",
    "isEnabled": true
  },
  {
    "id": 488,
    "code": "8992",
    "name": "Endive 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2626169010000",
    "barcodeSecours": "2000014319226",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_828/v1779699231/product/9c267c391adfe70fd6273b93d447e3a9.webp",
    "isEnabled": true
  },
  {
    "id": 489,
    "code": "578",
    "name": "Feggous 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624548005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1698917549/product/1744db3ed8beb6b7f749abf36042f8bd.webp",
    "isEnabled": true
  },
  {
    "id": 490,
    "code": "2082",
    "name": "Fenouil 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624871005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587309744/product_optimized/72229cc790fc67790248073243c7eb1e.webp",
    "isEnabled": true
  },
  {
    "id": 491,
    "code": "XXXX",
    "name": "Fenouil le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624871005000",
    "isEnabled": true
  },
  {
    "id": 492,
    "code": "XXXX",
    "name": "Fèves le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624872005000",
    "isEnabled": true
  },
  {
    "id": 493,
    "code": "6081",
    "name": "Gingembre frais 200g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624409002000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588286406/product_optimized/417ea82e19bdf8f495c6d394ad9c90eb.webp",
    "isEnabled": true
  },
  {
    "id": 494,
    "code": "2931",
    "name": "Girolle 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2626377001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1785233527/product/ea6774606e9132bd538ee49add3f02c9.webp",
    "isEnabled": true
  },
  {
    "id": 495,
    "code": "XXXX",
    "name": "Gombos en barquette 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624812005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789565588/product/f0d93eb932335b59aaebd7859c01f90a.webp",
    "isEnabled": true
  },
  {
    "id": 496,
    "code": "579",
    "name": "Haricot vert 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2625438005000",
    "barcodeMarjane": "2626254005000",
    "barcodeSecours": "2000014695818",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1745504596/product/935d2f9b443ab43783bd87821159d9ee.webp",
    "isEnabled": true
  },
  {
    "id": 497,
    "code": "XXXX",
    "name": "Haricots vert le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "isEnabled": true
  },
  {
    "id": 498,
    "code": "589",
    "name": "Navet jaune 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624897005000",
    "isEnabled": true
  },
  {
    "id": 499,
    "code": "XXXX",
    "name": "Navet jaunes le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624897005000",
    "isEnabled": true
  },
  {
    "id": 500,
    "code": "8208",
    "name": "Navet long 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624238005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587311314/product_optimized/611fb8847188e92cc231a4fcab4692e4.webp",
    "isEnabled": true
  },
  {
    "id": 501,
    "code": "-",
    "name": "Navet rond 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587311386/product_optimized/7a00e51a1bdcf8e516f1a1e035e245f0.webp",
    "isEnabled": true
  },
  {
    "id": 502,
    "code": "XXXX",
    "name": "Navets ronds le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624886005000",
    "isEnabled": true
  },
  {
    "id": 503,
    "code": "XXXX",
    "name": "Oignon blanc 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624587010000",
    "isEnabled": true
  },
  {
    "id": 504,
    "code": "9576",
    "name": "Oignon blanc 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2676540010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381719/product/a30cf71eefabcda499953593adc0ba6f.webp",
    "isEnabled": true
  },
  {
    "id": 505,
    "code": "8212",
    "name": "Oignon frais blanc 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624242010000",
    "isEnabled": true
  },
  {
    "id": 506,
    "code": "4415",
    "name": "Oignon frais blanc 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2688721010000",
    "isEnabled": true
  },
  {
    "id": 507,
    "code": "8213",
    "name": "Oignon frais rouge 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624243010000",
    "isEnabled": true
  },
  {
    "id": 508,
    "code": "4411",
    "name": "Oignon frais rouge 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2677876010000",
    "isEnabled": true
  },
  {
    "id": 509,
    "code": "XXXX",
    "name": "Oignon rouge 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624588010000",
    "isEnabled": true
  },
  {
    "id": 510,
    "code": "9539",
    "name": "Oignon rouge 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2654670010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381758/product/dc01c7aad0273204a36db9193559b5eb.webp",
    "isEnabled": true
  },
  {
    "id": 511,
    "code": "XXXX",
    "name": "Oingurge kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624819010000",
    "isEnabled": true
  },
  {
    "id": 512,
    "code": "9540",
    "name": "Patate douce 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2650001010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789734488/product/fe085bfdb98db5bc3f207af80ac5ca96.webp",
    "isEnabled": true
  },
  {
    "id": 513,
    "code": "XXXX",
    "name": "PDT blanche au kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624431010000",
    "isEnabled": true
  },
  {
    "id": 514,
    "code": "XXXX",
    "name": "PDT rouge au kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2624430010000",
    "isEnabled": true
  },
  {
    "id": 515,
    "code": "XXXX",
    "name": "Petits pois le kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2606807005000",
    "isEnabled": true
  },
  {
    "id": 516,
    "code": "-",
    "name": "Petits pois 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2606807005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587313418/product_optimized/f25ae241c1ce8e0b8c25df27e0428126.webp",
    "isEnabled": true
  },
  {
    "id": 517,
    "code": "577",
    "name": "Piment fort 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624558005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381883/product/36c834d5413a28afaa549f536e9bab9a.webp",
    "isEnabled": true
  },
  {
    "id": 518,
    "code": "XXXX",
    "name": "Piments fort rouge",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2619300005000",
    "isEnabled": true
  },
  {
    "id": 519,
    "code": "548",
    "name": "Poireau 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624803005000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1587314870/product_optimized/8d094e68ec73cb43d2299367b69b78df.webp",
    "isEnabled": true
  },
  {
    "id": 520,
    "code": "2422",
    "name": "Poivron jaune 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2677701005000",
    "barcodeSecours": "2000014716872",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1754403639/product/09db75f9336d3d41629d94df895aa614.webp",
    "isEnabled": true
  },
  {
    "id": 521,
    "code": "2421",
    "name": "Poivron rouge 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2677710005000",
    "barcodeSecours": "2000014716865",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1754403734/product/063c62cbad2c08b4bc44975df8195dab.webp",
    "isEnabled": true
  },
  {
    "id": 522,
    "code": "2995",
    "name": "Poivron vert 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2626266005000",
    "barcodeSecours": "2000014097629",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381916/product/f324f5d30a8bcbd6b1d161c06ce34e66.webp",
    "isEnabled": true
  },
  {
    "id": 523,
    "code": "7741",
    "name": "Pomme de terre blanche lavée 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2699785010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381798/product/4dc44d401677177ec5a2d0c2a23a3115.webp",
    "isEnabled": true
  },
  {
    "id": 524,
    "code": "2607",
    "name": "Pomme de terre blanche non lavée 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2600046010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1790162871/product/89d11902044d18341d684c4802e0a7a8.webp",
    "isEnabled": true
  },
  {
    "id": 525,
    "code": "-",
    "name": "Pomme de terre blanche non lavée en filet 2Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1790163143/product/444767d6cee7c7bc529eedfd8312e654.webp",
    "isEnabled": true
  },
  {
    "id": 526,
    "code": "526",
    "name": "Pomme de terre douce 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624829010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789734488/product/fe085bfdb98db5bc3f207af80ac5ca96.webp",
    "isEnabled": true
  },
  {
    "id": 527,
    "code": "9540",
    "name": "Pomme de terre douce 1Kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2650001010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789734488/product/fe085bfdb98db5bc3f207af80ac5ca96.webp",
    "isEnabled": true
  },
  {
    "id": 528,
    "code": "5805",
    "name": "Pomme de terre frite 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2677881010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751447201/product/0fd42a9d258ae1a1a7191d18635c6a9e.webp",
    "isEnabled": true
  },
  {
    "id": 529,
    "code": "-",
    "name": "Pomme de terre grenaille rouge en filet 500g - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1790164324/product/44d418e9a4f3297846abaced995bf9e2.webp",
    "isEnabled": true
  },
  {
    "id": 530,
    "code": "7740",
    "name": "Pomme de terre lavée 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2699789010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751381844/product/94d4abaa987e256950ef7f71340e7996.webp",
    "isEnabled": true
  },
  {
    "id": 531,
    "code": "XXXX",
    "name": "Pomme de terre rouge 1kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "isEnabled": true
  },
  {
    "id": 532,
    "code": "2605",
    "name": "Pomme de terre rouge non lavée 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2600578010000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1789398648/product/01561bc57d62fc512967b113da3004c7.webp",
    "isEnabled": true
  },
  {
    "id": 533,
    "code": "754",
    "name": "Portobello 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2624107001000",
    "isEnabled": true
  },
  {
    "id": 534,
    "code": "XXXX",
    "name": "Portobello locale au kg",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2633890004001",
    "isEnabled": true
  },
  {
    "id": 535,
    "code": "-",
    "name": "Radis rouge 500g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMarjane": "2626677015000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1698917090/product/1462032e007aecaf4a8b6a02780acd51.webp",
    "isEnabled": true
  },
  {
    "id": 536,
    "code": "4986",
    "name": "Shiitake 100g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2631404001000",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1765290920/product/53510586c4a4b47900e6f25e4ddcaaf0.webp",
    "isEnabled": true
  },
  {
    "id": 537,
    "code": "-",
    "name": "Tomate cerise allongée 250g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeSecours": "2000014576742",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1649776905/product_optimized/940b6927b8e74fd3a1c69e9b6db20f26.webp",
    "isEnabled": true
  },
  {
    "id": 538,
    "code": "-",
    "name": "Tomate cerise en barquette 250g",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMiniSecours": "3504181020019",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1588268179/product_optimized/85f86fdeff39a9f581a132e2f3651bcf.webp",
    "isEnabled": true
  },
  {
    "id": 539,
    "code": "7280",
    "name": "Tomate ronde 1Kg - FILIERE M",
    "department": "Fruits et légumes",
    "category": "Legumes",
    "barcodeMjValide": "2659879010000",
    "barcodeSecours": "2000014097759",
    "imageUrl": "https://res.cloudinary.com/dcphm6bor/image/upload/q_75,f_auto,w_640/v1751382220/product/a820bb11f69fe199bdf9fd131b9ca362.webp",
    "isEnabled": true
  },
  {
    "id": 540,
    "code": "-",
    "name": "Gâteaux aux amandes 250g",
    "department": "Boulangerie et pâtisserie",
    "category": "Patisserie",
    "barcodeMarjane": "2601244002500",
    "isEnabled": true
  },
  {
    "id": 541,
    "code": "-",
    "name": "Gâteaux sablés 250g",
    "department": "Boulangerie et pâtisserie",
    "category": "Patisserie",
    "barcodeMarjane": "2601245002500",
    "isEnabled": true
  },
  {
    "id": 542,
    "code": "-",
    "name": "Mini croissant 200g",
    "department": "Boulangerie et pâtisserie",
    "category": "Patisserie",
    "barcodeMarjane": "2600349002200",
    "isEnabled": true
  },
  {
    "id": 543,
    "code": "-",
    "name": "Mini pain au chocolat 200g",
    "department": "Boulangerie et pâtisserie",
    "category": "Patisserie",
    "barcodeMarjane": "2600351002000",
    "isEnabled": true
  }
];
