import { createServerClient } from "@supabase/ssr";

const supabaseUrl =
  (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_URL) ||
  "https://pssizsvkbgabnarlyawj.supabase.co";

const supabaseKey =
  (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY) ||
  "sb_publishable_Edhz1UUdYBSAmU65NCv08w_Z5u-D2mp";

export const createClient = (request?: any) => {
  let supabaseResponse = {
    next: () => ({ headers: new Headers() }),
  };

  const supabase = createServerClient(
    supabaseUrl!,
    supabaseKey!,
    {
      cookies: {
        getAll() {
          return request?.cookies?.getAll ? request.cookies.getAll() : [];
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }: any) => request?.cookies?.set?.(name, value));
        },
      },
    },
  );

  return supabaseResponse;
};
