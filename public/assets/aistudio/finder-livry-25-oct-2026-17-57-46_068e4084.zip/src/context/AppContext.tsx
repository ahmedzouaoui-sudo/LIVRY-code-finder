import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { Department, Product, Role, TipPost } from '../types';
import { INITIAL_PRODUCTS } from '../data/initialProducts';
import { parseProductsFromCsv, exportProductsToCsv } from '../utils/csvImporter';
import {
  checkSupabaseHealth,
  fetchProductsFromSupabase,
  upsertProductInSupabase,
  deleteProductInSupabase,
  seedProductsToSupabase,
  deleteAllProductsFromSupabase,
  fetchTipsFromSupabase,
  upsertTipInSupabase,
  seedTipsToSupabase,
  SupabaseHealthCheckResult,
} from '../services/supabaseService';
import { supabase, supabasePublic, supabaseApi } from '../services/supabaseClient';


export type ActiveTab = 'home' | 'library' | 'admin' | 'tips';

export interface SyncResult {
  success: boolean;
  count: number;
  addedCount: number;
  error?: string;
}

interface AppContextType {
  role: Role;
  setRole: (role: Role) => void;
  products: Product[];
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectedDepartment: Department | null;
  setSelectedDepartment: (dept: Department | null) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  toggleProductStatus: (id: number) => Promise<void>;
  updateProduct: (updated: Product) => Promise<void>;
  addProduct: (newProduct: Omit<Product, 'id'>) => Promise<void>;
  deleteProduct: (id: number) => Promise<void>;
  resetCatalogue: () => void;
  clearAllProducts: () => Promise<void>;
  seedInitialCatalogueToSupabase: () => Promise<void>;
  syncWithSupabase: (isManual?: boolean) => Promise<SyncResult>;
  syncWithFirebase: (isManual?: boolean) => Promise<SyncResult>; // Alias for backward compatibility
  seedSupabase: () => Promise<void>;
  seedTips: () => Promise<void>;
  supabaseHealth: SupabaseHealthCheckResult | null;
  checkSupabaseStatus: () => Promise<SupabaseHealthCheckResult | null>;
  syncStatus: 'idle' | 'syncing' | 'synced' | 'error';
  isSyncing: boolean;
  syncProgress: { processed: number; total: number } | null;
  lastSyncTimestamp: string | null;
  importProductsCsv: (csvContent: string, mode?: 'merge' | 'replace') => { success: boolean; count: number; error?: string };
  exportCatalogueCsv: () => string;
  tips: TipPost[];
  addTip: (tip: Omit<TipPost, 'id' | 'createdAt' | 'likes'>) => void;
  updateTip: (updated: TipPost) => void;
  deleteTip: (id: string) => void;
  likeTip: (id: string) => void;
}

const STORAGE_KEY_PRODUCTS = 'finder_livry_products_v3';
const STORAGE_KEY_ROLE = 'finder_livry_role_v1';
const STORAGE_KEY_LAST_SYNC = 'finder_livry_last_sync_v3';
const STORAGE_KEY_TIPS = 'finder_livry_tips_v1';

const INITIAL_TIPS: TipPost[] = [
  {
    id: 'tip-1',
    title: 'Scanner une étiquette humide ou froissée',
    content:
      'Aux rayons Boucherie et Surgelés, la buée ou le film plastique froissé empêche la douchette de biper. Astuce : Ouvrez la fiche produit sur Finder Livry et cliquez sur le bouton Plein écran pour scanner le code directement sur votre smartphone.',
    category: 'Scanner & Caisse',
    authorRole: 'Pickeur',
    authorName: 'Ahmed (Lead Pickeur)',
    targetAudience: 'Tous',
    createdAt: 'Il y a 2 jours',
    likes: 14,
  },
  {
    id: 'tip-2',
    title: 'Pesée balance en panne ou illisible',
    content:
      'Si la balance du rayon Fruits & Légumes ne sort pas de code, vérifiez l\'unité du produit (ex: 500g ou 100g). Utilisez le stepper (-) et (+) pour multiplier le poids exact (ex: 100g x 5 = 500g). Le code-barres s\'ajuste automatiquement avec la clé de pesée Marjane.',
    category: 'Pesée & Balance',
    authorRole: 'Pickeur',
    authorName: 'Yassine',
    targetAudience: 'Pickeur',
    createdAt: 'Il y a 3 jours',
    likes: 9,
  },
  {
    id: 'tip-3',
    title: 'Code XXXX ou produit non répertorié',
    content:
      'Les codes marqués XXXX sont masqués du catalogue public. Si vous rencontrez un article sans code au stand Fromage ou Boucherie, prenez une photo et transmettez le nom à l\'Admin pour qu\'il le saisisse dans le panneau d\'import CSV.',
    category: 'Général',
    authorRole: 'Admin',
    authorName: 'Admin Livry',
    targetAudience: 'Tous',
    createdAt: 'Cette semaine',
    likes: 18,
  },
  {
    id: 'tip-4',
    title: 'Astuce rapidité pour les Livreurs en caisse',
    content:
      'Mettez la luminosité de votre téléphone à 100% avant d\'arriver au tapis de caisse. Les douchettes laser Marjane bipent en moins de 0.2 seconde sur écran blanc lumineux.',
    category: 'Scanner & Caisse',
    authorRole: 'Livreur',
    authorName: 'Karim',
    targetAudience: 'Livreur',
    createdAt: 'Hier',
    likes: 12,
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<Role>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ROLE);
    return (saved as Role) || 'Pickeur';
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      localStorage.removeItem('finder_livry_products_v2');
      const cached = localStorage.getItem(STORAGE_KEY_PRODUCTS);
      if (cached !== null) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Error reading local cache:', e);
    }
    return INITIAL_PRODUCTS;
  });

  const [tips, setTips] = useState<TipPost[]>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY_TIPS);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Error reading local tips cache:', e);
    }
    return INITIAL_TIPS;
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced' | 'error'>('idle');
  const [syncProgress, setSyncProgress] = useState<{ processed: number; total: number } | null>(null);
  const [supabaseHealth, setSupabaseHealth] = useState<SupabaseHealthCheckResult | null>(null);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<string | null>(() => {
    return localStorage.getItem(STORAGE_KEY_LAST_SYNC) || 'Prêt pour la synchronisation';
  });

  // Reference to current products to avoid stale closures in timers
  const productsRef = useRef<Product[]>(products);
  useEffect(() => {
    productsRef.current = products;
  }, [products]);

  const isSyncing = syncStatus === 'syncing';
  const syncingRef = useRef(false);

  // Toast notification helper
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  }, []);

  // Sync products to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.warn('Local storage write limit or error:', e);
    }
  }, [products]);

  // Sync tips to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TIPS, JSON.stringify(tips));
    } catch (e) {
      console.warn('Tips storage error:', e);
    }
  }, [tips]);

  // Check Supabase status
  const checkSupabaseStatus = useCallback(async () => {
    try {
      const health = await checkSupabaseHealth();
      setSupabaseHealth(health);
      return health;
    } catch (err) {
      console.warn('Supabase health check error:', err);
      return null;
    }
  }, []);

  // Main synchronization function (manual or automatic)
  const syncWithSupabase = useCallback(
    async (isManual = false): Promise<SyncResult> => {
      if (syncingRef.current) {
        return { success: false, count: productsRef.current.length, addedCount: 0, error: 'Synchronisation déjà en cours' };
      }

      syncingRef.current = true;
      setSyncStatus('syncing');

      if (isManual) {
        showToast('Synchronisation avec la base de données...');
      }

      try {
        const health = await checkSupabaseHealth();
        setSupabaseHealth(health);

        if (!health.connected) {
          setSyncStatus('error');
          const errorMsg = 'Impossible de contacter Supabase (Vérifiez la connexion internet)';
          if (isManual) showToast(`❌ ${errorMsg}`);
          syncingRef.current = false;
          return { success: false, count: productsRef.current.length, addedCount: 0, error: errorMsg };
        }

        if (!health.tableExists) {
          setSyncStatus('error');
          const errorMsg = "La table 'products' n'a pas encore été créée dans Supabase";
          if (isManual) showToast(`⚠️ ${errorMsg}`);
          syncingRef.current = false;
          return { success: false, count: productsRef.current.length, addedCount: 0, error: errorMsg };
        }

        // Fetch remote data
        const res = await fetchProductsFromSupabase();
        if (res.success) {
          const remoteProducts = res.products;
          const currentList = productsRef.current;
          const previousCount = currentList.length;
          const newCount = remoteProducts.length;

          // Check if there are newly added items
          const currentIdSet = new Set(currentList.map((p) => p.id));
          const addedItems = remoteProducts.filter((p) => !currentIdSet.has(p.id));
          const addedCount = addedItems.length;

          // Check if data changed
          const hasChanged =
            newCount !== previousCount ||
            addedCount > 0 ||
            JSON.stringify(remoteProducts) !== JSON.stringify(currentList);

          if (hasChanged) {
            setProducts(remoteProducts);
          }

          const nowTime = new Date().toLocaleTimeString('fr-FR', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          });
          const syncNote = `Synchronisé (${newCount} produit${newCount > 1 ? 's' : ''} à ${nowTime})`;
          setLastSyncTimestamp(syncNote);
          localStorage.setItem(STORAGE_KEY_LAST_SYNC, syncNote);
          setSyncStatus('synced');

          if (isManual) {
            if (addedCount > 0) {
              showToast(`✅ Mise à jour réussie : ${newCount} produits (+${addedCount} nouveau${addedCount > 1 ? 'x' : ''}) !`);
            } else if (newCount > 0) {
              showToast(`✅ Catalogue à jour : ${newCount} produit${newCount > 1 ? 's' : ''} disponible${newCount > 1 ? 's' : ''}`);
            } else {
              showToast('ℹ️ Base connectée : 0 produit dans la base Supabase');
            }
          } else if (addedCount > 0) {
            showToast(`🔄 Mise à jour auto : ${addedCount} nouveau${addedCount > 1 ? 'x' : ''} produit${addedCount > 1 ? 's' : ''} ajouté${addedCount > 1 ? 's' : ''} depuis la base !`);
          }

          syncingRef.current = false;
          return { success: true, count: newCount, addedCount };
        } else {
          setSyncStatus('error');
          if (isManual) {
            showToast(`❌ Erreur Supabase : ${res.error}`);
          }
          syncingRef.current = false;
          return { success: false, count: productsRef.current.length, addedCount: 0, error: res.error };
        }
      } catch (err: any) {
        setSyncStatus('error');
        if (isManual) {
          showToast(`❌ Erreur de synchronisation : ${err.message}`);
        }
        syncingRef.current = false;
        return { success: false, count: productsRef.current.length, addedCount: 0, error: err.message };
      }
    },
    [showToast]
  );

  // Initial pull from Supabase on mount
  useEffect(() => {
    let isMounted = true;
    const initializeRemoteData = async () => {
      const health = await checkSupabaseHealth();
      if (!isMounted) return;
      setSupabaseHealth(health);

      if (health.connected && health.tableExists) {
        const res = await fetchProductsFromSupabase();
        if (isMounted && res.success) {
          setProducts(res.products);
          const nowTime = new Date().toLocaleTimeString('fr-FR', {
            hour: '2-digit',
            minute: '2-digit',
          });
          const note = `Supabase synchronisé (${res.products.length} produit${res.products.length > 1 ? 's' : ''} à ${nowTime})`;
          setLastSyncTimestamp(note);
          localStorage.setItem(STORAGE_KEY_LAST_SYNC, note);
          setSyncStatus('synced');
        }

        // Fetch remote tips
        const tipsRes = await fetchTipsFromSupabase();
        if (isMounted && tipsRes.success) {
          if (tipsRes.tips.length > 0) {
            setTips(tipsRes.tips);
          } else {
            await seedTipsToSupabase(INITIAL_TIPS);
          }
        }
      }
    };

    initializeRemoteData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Automatic Background Polling (Every 12 seconds) & Window Focus Listener
  useEffect(() => {
    // 1. Polling interval every 12 seconds
    const intervalId = setInterval(() => {
      if (document.visibilityState === 'visible') {
        syncWithSupabase(false).catch(console.warn);
      }
    }, 12000);

    // 2. Refresh immediately when user switches tabs or focuses the window
    const handleTabFocus = () => {
      if (document.visibilityState === 'visible') {
        syncWithSupabase(false).catch(console.warn);
      }
    };

    window.addEventListener('focus', handleTabFocus);
    document.addEventListener('visibilitychange', handleTabFocus);

    return () => {
      clearInterval(intervalId);
      window.removeEventListener('focus', handleTabFocus);
      document.removeEventListener('visibilitychange', handleTabFocus);
    };
  }, [syncWithSupabase]);

  // Real-time Bidirectional Sync via Supabase Channels (site <-> app)
  useEffect(() => {
    let isMounted = true;

    // Public schema channel
    const channelPub = supabasePublic
      .channel('realtime-db-sync-public')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'products' },
        async (payload) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime Public] Changement détecté sur products:', payload.eventType);
          await syncWithSupabase(false);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tips' },
        async (payload) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime Public] Changement détecté sur tips:', payload.eventType);
          const res = await fetchTipsFromSupabase();
          if (res.success && isMounted && res.tips.length > 0) {
            setTips(res.tips);
          }
        }
      )
      .subscribe((status, err) => {
        if (err) {
          console.warn('[Supabase Realtime Public] Status channel:', status, err);
        }
      });

    // API schema channel
    const channelApi = supabaseApi
      .channel('realtime-db-sync-api')
      .on(
        'postgres_changes',
        { event: '*', schema: 'api', table: 'products' },
        async (payload) => {
          if (!isMounted) return;
          console.log('[Supabase Realtime API] Changement détecté sur products:', payload.eventType);
          await syncWithSupabase(false);
        }
      )
      .subscribe((status, err) => {
        if (err) {
          console.warn('[Supabase Realtime API] Status channel:', status, err);
        }
      });

    return () => {
      isMounted = false;
      supabasePublic.removeChannel(channelPub);
      supabaseApi.removeChannel(channelApi);
    };
  }, [syncWithSupabase]);

  const setRole = (newRole: Role) => {
    setRoleState(newRole);
    localStorage.setItem(STORAGE_KEY_ROLE, newRole);
    if (newRole === 'Admin') {
      setActiveTab('admin');
    }
    showToast(`Rôle activé : ${newRole}`);
  };

  const toggleProductStatus = async (id: number) => {
    let targetProduct: Product | undefined;
    setProducts((prev) => {
      const updated = prev.map((p) => {
        if (p.id === id) {
          const toggled = { ...p, isEnabled: !p.isEnabled };
          targetProduct = toggled;
          return toggled;
        }
        return p;
      });
      return updated;
    });

    if (targetProduct) {
      const res = await upsertProductInSupabase(targetProduct);
      if (!res.success) {
        showToast(`⚠️ Statut mis à jour localement (Erreur Supabase: ${res.error})`);
      } else {
        showToast('Statut du produit mis à jour');
      }
    }
  };

  const updateProduct = async (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (selectedProduct?.id === updated.id) {
      setSelectedProduct(updated);
    }

    const res = await upsertProductInSupabase(updated);
    if (!res.success) {
      showToast(`⚠️ Produit enregistré localement mais erreur Supabase : ${res.error}`);
    } else {
      showToast('✅ Produit enregistré dans l\'application et Supabase !');
    }
  };

  const addProduct = async (newProduct: Omit<Product, 'id'>) => {
    // Generate safe positive integer ID
    const maxExisting = productsRef.current.reduce((max, p) => (p.id > max ? p.id : max), 0);
    const nextId = maxExisting > 0 ? maxExisting + 1 : Math.floor(Date.now() % 1000000000);

    const fullProd: Product = { ...newProduct, id: nextId };
    setProducts((prev) => [fullProd, ...prev]);

    const res = await upsertProductInSupabase(fullProd);
    if (!res.success) {
      showToast(`⚠️ Produit "${fullProd.name}" ajouté localement (Erreur Supabase: ${res.error})`);
    } else {
      showToast(`✅ Produit "${fullProd.name}" synchronisé sur Supabase !`);
    }
  };

  const deleteProduct = async (id: number) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    if (selectedProduct?.id === id) {
      setSelectedProduct(null);
    }

    const res = await deleteProductInSupabase(id);
    if (!res.success) {
      showToast(`⚠️ Supprimé localement (Erreur Supabase: ${res.error})`);
    } else {
      showToast('Produit supprimé du catalogue et de Supabase');
    }
  };

  const clearAllProducts = async () => {
    setProducts([]);
    try {
      localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify([]));
    } catch (e) {
      console.warn(e);
    }
    try {
      await deleteAllProductsFromSupabase();
      await checkSupabaseStatus();
    } catch (e) {
      console.warn('Error clearing Supabase:', e);
    }
    showToast('Tous les produits ont été supprimés (0 produit). Prêt pour le test Supabase !');
  };

  const resetCatalogue = async () => {
    setProducts(INITIAL_PRODUCTS);
    try {
      localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
    } catch (e) {
      console.warn(e);
    }
    showToast('Restauration du catalogue (543 articles) vers Supabase...');
    await seedInitialCatalogueToSupabase();
  };

  const seedInitialCatalogueToSupabase = async () => {
    setSyncStatus('syncing');
    setSyncProgress({ processed: 0, total: INITIAL_PRODUCTS.length });
    showToast(`Envoi des 543 articles officiels vers Supabase...`);

    try {
      const res = await seedProductsToSupabase(INITIAL_PRODUCTS, (processed, total) => {
        setSyncProgress({ processed, total });
      });

      if (res.success) {
        setProducts(INITIAL_PRODUCTS);
        const nowStr = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
        const syncNote = `Synchronisé (${res.count} produits envoyés à ${nowStr})`;
        setLastSyncTimestamp(syncNote);
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, syncNote);
        setSyncStatus('synced');
        setSyncProgress(null);
        await checkSupabaseStatus();
        showToast(`Succès : ${res.count} produits enregistrés sur Supabase !`);
      } else {
        setSyncStatus('error');
        setSyncProgress(null);
        showToast(`Erreur d'envoi : ${res.error}`);
      }
    } catch (err: any) {
      setSyncStatus('error');
      setSyncProgress(null);
      showToast(`Erreur : ${err.message}`);
    }
  };

  const importProductsCsv = (csvContent: string, mode: 'merge' | 'replace' = 'merge') => {
    const { products: parsed, error } = parseProductsFromCsv(csvContent);
    if (error || !parsed || parsed.length === 0) {
      showToast(error || 'Échec de lecture du fichier CSV');
      return { success: false, count: 0, error: error || 'Format invalide' };
    }

    if (mode === 'replace') {
      setProducts(parsed);
      showToast(`${parsed.length} produits importés (catalogue remplacé)`);
      return { success: true, count: parsed.length };
    }

    let updatedCount = 0;
    let addedCount = 0;

    setProducts((prev) => {
      const copy = [...prev];
      const maxId = Math.max(...prev.map((p) => p.id), 0);
      let currentNewId = maxId + 1;

      for (const item of parsed) {
        const matchIdx = copy.findIndex(
          (p) =>
            (item.code !== '-' && item.code !== 'XXXX' && p.code.toLowerCase() === item.code.toLowerCase()) ||
            p.name.trim().toLowerCase() === item.name.trim().toLowerCase()
        );

        if (matchIdx !== -1) {
          copy[matchIdx] = {
            ...copy[matchIdx],
            code: item.code !== '-' ? item.code : copy[matchIdx].code,
            barcodeMjValide: item.barcodeMjValide || copy[matchIdx].barcodeMjValide,
            barcodeMarjane: item.barcodeMarjane || copy[matchIdx].barcodeMarjane,
            barcodeSecours: item.barcodeSecours || copy[matchIdx].barcodeSecours,
            barcodeMiniSecours: item.barcodeMiniSecours || copy[matchIdx].barcodeMiniSecours,
            barcodeP2: item.barcodeP2 || copy[matchIdx].barcodeP2,
            barcodeP3: item.barcodeP3 || copy[matchIdx].barcodeP3,
            imageUrl: item.imageUrl || copy[matchIdx].imageUrl,
          };
          updatedCount++;
        } else {
          copy.push({
            ...item,
            id: currentNewId++,
          });
          addedCount++;
        }
      }

      return copy;
    });

    const msg = `${updatedCount} produits mis à jour, ${addedCount} nouveaux ajoutés`;
    showToast(msg);
    return { success: true, count: updatedCount + addedCount };
  };

  const exportCatalogueCsv = () => {
    return exportProductsToCsv(products);
  };

  // Tips Management
  const addTip = (newTip: Omit<TipPost, 'id' | 'createdAt' | 'likes'>) => {
    const post: TipPost = {
      ...newTip,
      id: `tip-${Date.now()}`,
      createdAt: 'À l\'instant',
      likes: 0,
    };
    setTips((prev) => [post, ...prev]);
    upsertTipInSupabase(post).catch(console.warn);
    showToast('Tuto / Astuce publié avec succès !');
  };

  const updateTip = (updated: TipPost) => {
    setTips((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
    upsertTipInSupabase(updated).catch(console.warn);
    showToast('Tuto mis à jour avec succès');
  };

  const deleteTip = (id: string) => {
    setTips((prev) => prev.filter((t) => t.id !== id));
    showToast('Astuce supprimée');
  };

  const likeTip = (id: string) => {
    setTips((prev) => {
      const updated = prev.map((t) => {
        if (t.id === id) {
          const item = { ...t, likes: t.likes + 1 };
          upsertTipInSupabase(item).catch(console.warn);
          return item;
        }
        return t;
      });
      return updated;
    });
  };

  // Seed / Push all local products to Supabase
  const seedSupabase = async () => {
    if (products.length === 0) {
      showToast('Aucun produit dans le tableau à envoyer. Utilisez "Envoyer 543 articles initiaux" ou importez un CSV.');
      return;
    }

    setSyncStatus('syncing');
    setSyncProgress({ processed: 0, total: products.length });
    showToast(`Envoi de ${products.length} produits vers Supabase...`);

    try {
      const res = await seedProductsToSupabase(products, (processed, total) => {
        setSyncProgress({ processed, total });
      });

      if (res.success) {
        const nowStr = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
        const syncNote = `Synchronisé (${res.count} produits envoyés à ${nowStr})`;
        setLastSyncTimestamp(syncNote);
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, syncNote);
        setSyncStatus('synced');
        setSyncProgress(null);
        await checkSupabaseStatus();
        showToast(`Succès : ${res.count} produits enregistrés sur Supabase !`);
      } else {
        setSyncStatus('error');
        setSyncProgress(null);
        showToast(`Erreur d'envoi : ${res.error}`);
      }
    } catch (err: any) {
      setSyncStatus('error');
      setSyncProgress(null);
      showToast(`Erreur : ${err.message}`);
    }
  };

  // Seed / Push all tips to Supabase
  const seedTips = async () => {
    setSyncStatus('syncing');
    showToast(`Envoi de ${tips.length} tutoriels vers Supabase...`);
    try {
      const res = await seedTipsToSupabase(tips);
      if (res.success) {
        setSyncStatus('synced');
        showToast(`Succès : ${res.count} tutoriels enregistrés sur Supabase !`);
      } else {
        setSyncStatus('error');
        showToast(`Erreur d'envoi des tutoriels : ${res.error}`);
      }
    } catch (err: any) {
      setSyncStatus('error');
      showToast(`Erreur : ${err.message}`);
    }
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        products,
        activeTab,
        setActiveTab,
        selectedDepartment,
        setSelectedDepartment,
        selectedProduct,
        setSelectedProduct,
        searchQuery,
        setSearchQuery,
        toastMessage,
        showToast,
        toggleProductStatus,
        updateProduct,
        addProduct,
        deleteProduct,
        resetCatalogue,
        clearAllProducts,
        seedInitialCatalogueToSupabase,
        syncWithSupabase,
        syncWithFirebase: syncWithSupabase,
        seedSupabase,
        seedTips,
        supabaseHealth,
        checkSupabaseStatus,
        syncStatus,
        isSyncing,
        syncProgress,
        lastSyncTimestamp,
        importProductsCsv,
        exportCatalogueCsv,
        tips,
        addTip,
        updateTip,
        deleteTip,
        likeTip,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
