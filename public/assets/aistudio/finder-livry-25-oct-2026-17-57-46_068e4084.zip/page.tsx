import React, { useEffect, useState } from 'react';
import { createClient } from './utils/supabase/client';

export default function Page() {
  const [todos, setTodos] = useState<any[]>([]);
  const supabase = createClient();

  useEffect(() => {
    supabase
      .from('todos')
      .select('*')
      .then(({ data }) => {
        if (data) setTodos(data);
      });
  }, []);

  return (
    <ul className="p-4 space-y-2">
      {todos?.map((todo) => (
        <li key={todo.id} className="p-2 border rounded">
          {todo.name}
        </li>
      ))}
    </ul>
  );
}
